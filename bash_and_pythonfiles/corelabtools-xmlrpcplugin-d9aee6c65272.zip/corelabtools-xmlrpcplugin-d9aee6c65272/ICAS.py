#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 18 08:47:45 2017

@author: sorenc
"""



import  xmlrpclib
from osirixutils import *
import time
import icas_sheet

server = xmlrpclib.Server("http://172.25.169.100:8080",verbose=False)




#set up labelling rules
#ncctrule=LabelPattern('NCCT','head|noncon|non con|soft|non|5mm axial|H41s|axial|brain','bone|cor|sag|mip|ax bn',slicesmin=5,slicesmax=2000,framesmin=-1,framesmax=2,modality='CT') #frames=-1 allows no isophasic
tofrule=LabelPattern('TOF','tof|mra|pjn|mip|cow|spin|tumble|reformat|right|left|posterior|processed images','bone',slicesmin=1,slicesmax=2000,framesmin=-1,framesmax=100,modality='MR')
clearrule=LabelPattern('','.*','NOMATCH')
dwirule=LabelPattern('DWI','dwi|diff','exponen|adc|apparent|RAPID')
mrprule=LabelPattern('PWI','pwi|perf','TTP|screensave|fmri',slicesmin=1,slicesmax=320,framesmin=30,framesmax=100,modality='MR')
flairrule=LabelPattern('FLAIR','flair|tirm','bone',slicesmin=1,slicesmax=2000,framesmin=-1,framesmax=100,modality='MR')
#ctprule=LabelPattern('CTP','perf|shuttle|axial|40cc|above','bone',slicesmin=2,slicesmax=320,framesmin=10,framesmax=100,modality='CT')
#ctarule=LabelPattern('CTA','thin|cow|cta|angio','perf|ctp|above',slicesmin=-1,slicesmax=2000,framesmin=-1,framesmax=100,modality='CT')

#corclear=LabelPattern('','COR DIFFUSION','NOMATCH')

ruleset=[mrprule,dwirule]



#connect
IDs=server.getPatientIDs( )
sortedIDs=sorted(IDs)
sortedIDs=sortedIDs

for cid in sortedIDs[81:]: #sortedIDs: #sortedIDs:  #sortedIDs[0:1]:
    #iterate series and label each series
    print cid
    studies=server.PatientIDtoStudies(  {"patientID": cid})  
    
    #for s in studies:
    #    server.SetComment2forStudy({"studyInstanceUID": s["studyInstanceUID"] , "Comment":"" } )  
    
    
    seriesdicts=getImageSeriesUIDsForStudies(server,studies)
    
    
   # labelcomment2forstudy(seriesdicts,server,ruleset,dryrun=0)      #label the series if there is a match
    labelcomment3forseries(seriesdicts,server,ruleset,dryrun=0)      #label the series if there is a match
    time.sleep(1)
            




bl_times=icas_sheet.getBLtimes()

for cid in sortedIDs[81:]:   #sortedIDs[74:75]:   #sortedIDs[0:10]:
    
    if not bl_times.has_key(cid):  #some patients are not in the sheet all all
        print cid + " is not in the sheet"
        continue

    BLtime=bl_times[cid]
    

    
    BL_trange_min=BLtime - timedelta(hours=6)
    BL_trange_max=BLtime + timedelta(hours=2)  #we dont want to capture the eFU here
    crule=PatientTimePointLabel(cid,'BL',[BL_trange_min,BL_trange_max])

    crule.labelstudies(server,dryrun=0)
    time.sleep(1)




for cid in []: #sortedIDs: #sortedIDs: #sortedIDs:  #sortedIDs[0:1]:
    #iterate series and label each series

    studies=server.PatientIDtoStudies(  {"patientID": cid})  
    
    BLstudies=[]
    for k in studies:
        if k.has_key("comment2") and k["comment2"]=="BL":
            BLstudies.append(k)
            
            
    seriesdicts=getImageSeriesUIDsForStudies(server,BLstudies)
    
    
    dwipwiseries=[]
    for k in seriesdicts:
        if k.has_key("comment3") and (k["comment3"]=="PWI" or k["comment3"]=="DWI"):
            dwipwiseries.append(k)
    
    
    #iterate series to transfer
    for k in dwipwiseries:    
        targetfolder="/Users/sorenc/NCCT_B2/"+ cid[0:5] +"/"+k["comment3"] + "_"+k["seriesDICOMUID"]
        get_dicom_for_series_ICAS(server,k["seriesInstanceUID"],targetfolder)
                
    
   # labelcomment2forstudy(seriesdicts,server,ruleset,dryrun=0)      #label the series if there is a match
    


#IDs=server.getPatientIDs( )



#label series

#studies=server.PatientIDtoStudies(  {"patientID": '212'} )  


#seriesdicts=getImageSeriesUIDsForStudies(server,studies)


#server.SeriesUIDtoImages({"seriesInstanceUID":   seriesUID })
