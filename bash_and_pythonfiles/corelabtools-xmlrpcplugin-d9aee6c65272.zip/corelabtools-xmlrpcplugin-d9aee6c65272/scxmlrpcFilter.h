//
//  scxmlrpcFilter.m
//  scxmlrpc
//

#import <Foundation/Foundation.h>
#import "OsiriXAPI/PluginFilter.h"

@interface scxmlrpcFilter : PluginFilter {

}

- (long) filterImage:(NSString*) menuName;

@end
