#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 17 05:46:07 2017

@author: sorenc
"""



