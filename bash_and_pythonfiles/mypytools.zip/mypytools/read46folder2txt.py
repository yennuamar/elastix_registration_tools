#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 20 20:49:38 2016

@author: sorenc
"""

import rapid46
import sys


opfoldername=sys.argv[1]


op=rapid46.RAPID46OP(opfoldername,False)

volume=op.corethreshvols()["volumes"][0]


print volume