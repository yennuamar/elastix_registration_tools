# -*- coding: utf-8 -*-
"""
Created on Sun Aug 14 20:49:48 2016

@author: sorenc
"""
import json


fid=open('data.txt', 'r')
a=json.load(fid)
fid.close()



import csv
csvfile='/home/sorenc/CODE/mypytools/casenames.csv'
#csvfile="/home/sorenc/TESTS/assessment451.csv"
csvobj=csv.DictReader(open(csvfile))
myfieldnames=csvobj.fieldnames

dat=list(csvobj)


#the above contains ID and then the filters.

filternames=myfieldnames[1:]

myfilters_sheet={}
myfilters_out={}

for ifilter in filternames:
    currentvalues = [1 if r[ifilter] else 0 for r in dat]
    myfilters_sheet[ifilter]=currentvalues
    
sheetIDs = [r["ID"] for r in dat]
#artefact_tmax=np.zeros(len(lst),dtype=np.uint8)   #does not include failures
#artefact_aif=np.zeros(len(lst),dtype=np.uint8)   #does not include failures

#get the sheet indices for our IDs 
sheetindices=[]
for cID in a["allIDs"]:  #make sure we follow the ID order+length from above
    sheetindices.append(sheetIDs.index(cID))   #will crash if ID was not in sheet but it is required to be
    #where is this in the original list
    #now append the filter status
 
#now get the correct filter values into our output filter array
for ifilter in filternames:
    currentfilter=[]
    for iINDX in sheetindices:
         currentfilter.append( myfilters_sheet[ifilter][iINDX] )       
         
    myfilters_out[ifilter]=currentfilter         
      
      
#analysis["artefact_tmax"]=artefact_tmax.tolist()    
#nalysis["artefact_aif"]=artefact_aif.tolist()     

#try writing as json

#parse into json for flot
#non artefact cases
#allID=analysis["IDs"]
#allcores_merged=[list(a) for a in zip( analysis["corearray"][0],analysis["corearray"][1])]
#allhypo_merged=[list(a) for a in zip( analysis["tmaxarray"][0],analysis["tmaxarray"][1])]
#isCT=analysis["modalarray"][0]



#store images in dict by ID - this will make it easy to locate them using js

#allIMGlocations=zip(analysis["imagesV1allpng"],analysis["imagesV2allpng"])

#all_summaryimage_indices=  zip(analysis["imagesV1summary"],analysis["imagesV2summary"])
#all_aifplot_indices=  zip(analysis["imagesV1aifplot"],analysis["imagesV2aifplot"])
#all_aifloc_indices=  zip(analysis["imagesV1aifloc"],analysis["imagesV2aifloc"])

a["myfilters"]=myfilters_out



with open('data1.txt', 'w') as outfile:
    json.dump(a, outfile)

