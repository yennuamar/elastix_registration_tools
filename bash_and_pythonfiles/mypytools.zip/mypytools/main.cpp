#include "sc_itkimporter.h"
#include <QString>
#include <QDir>

int main(int argc,char **argv)
{
    sc_itkimporter importer;


    std::string mystr="/home/sorenc/CODE/rapid_4_6/source/backend/build-perf_mismatch-Desktop_Qt_5_5_1_GCC_64bit-Default/post_volume_slab0_band0_timepoint*mhd";
    importer.readFiles(mystr);

//    QString mystr("/home/sorenc/CODE/rapid_4_6/source/backend/build-perf_mismatch-Desktop_Qt_5_5_1_GCC_64bit-Default/");

//    QDir focusdir(mystr);
//    focusdir.setNameFilters(QStringList()<<"post_volume_slab0_band0_timepoint*mhd");
//    QStringList fileList = focusdir.entryList();

//    //prepend path..
//    for (int k=0; k<fileList.size(); k++)
//    {
//        fileList[k]=mystr+fileList[k];
//    }

//    importer->readFiles(fileList); //assumed to be list of volumes that will be read

    //delete importer;
    return 0;
}
