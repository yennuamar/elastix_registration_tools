#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 13 11:23:47 2017

@author: sorenc
"""

import xlsx
import rapid451
import rapid46
import glob
import os
import json
import xlrd
import datetime
import dicom
#script to iterate list of DEFUSE3 patients and record Tmax and core volumes + other info for BL and FU scans. The folders are the result folder to be used for DEFUSE 3
#eg  119/BL/      
#The script will search for links ending in '_use' and capture the volumes from those folders
 



#1) read list containng BL and FU foldernames
#2) go over this list and determine if BL or FU
#3) Search for _use folders and determine if dual slab, single slab or dwi  or dwi_pwi
#4  For each slab (if multiple, start with slab1)
#5)           determine if folder contains EXCLUSION.txt or SALVAGE.txt and if 4.6 or 4.5.1 and read it if not EXCLUSION.txt
#6)           read, tmax6, tmax10 and core (or just core if DWI only) + seriestime or exclusion reason if needed.
#7)           Fill in a list with info:  Tmax6_bl_slab1	Tmax10_bl_slab1	Core_bl_slab1	slab1_comment	slab1_coverage	Tmax6_bl_slab2	Tmax10_bl_slab2	Core_bl_slab2	slab2_comment , slab1time, slab2time, tmax6_total, tmax10_total, core_total, total_coverage slab1iscorelab, slab2iscorelab, slab1_tmax6_orig, slab1_tmax10_orig, slab1_core_orig, slab2_tmax6_orig, slab2_tmax10_orig, slab2_core_orig, difference_to_webdcu
#8)           



def get_usefolders(folder):
    usefolders=glob.glob(folder+'/*use')       
    return usefolders



def rapidX(folder):
    results={'tmax6_orig_total':-1,'tmax10_orig_total':-1,'core_orig_total':-1,'tmax6_corr_total':-1,'tmax10_corr_total':-1,'core_corr_total':-1,"numberofslabs":-1,'tmax6_orig_slab1':-1,'tmax10_orig_slab1':-1,'core_orig_slab1':-1,'tmax6_corr_slab1':-1,'tmax10_corr_slab1':-1,'core_corr_slab1':-1,'tmax6_orig_slab2':-1,'tmax10_orig_slab2':-1,'core_orig_slab2':-1,'tmax6_corr_slab2':-1,'tmax10_corr_slab2':-1,'core_corr_slab2':-1,'version_slab1':-1,'version_slab2':-1,'DateTime':'NA','DateTime_slab1':'NA','DateTime_slab2':'NA','errormsg':'','statuscode':-10,'slab1_zcoverage':-1,'slab2_zcoverage':-1,'zcoverage':-1}
    
    if os.path.exists(folder + '/output.json'):
        op=rapid46.RAPID46OP(folder)
        results["numberofslabs"]=op.numberofslabs        
        results["errormsg"]=op.errormessage
        results["statuscode"]=op.statuscode
        results["modality"]=op.modality

        
        if results["numberofslabs"]==1:
            results["tmax6_orig_total"]=op.tmaxthreshvols()["volumes"][1]
            results["tmax10_orig_total"]=op.tmaxthreshvols()["volumes"][3]
            results["core_orig_total"]=op.corethreshvols()["volumes"][0]
            results["version_slab1"]='R46' 
            results["zcoverage"]=op.zcoverage
            results["DateTime"]=op.SeriesDateTime
            
        if results["numberofslabs"]==2:
            results["tmax6_orig_slab1"]=op.tmaxthreshvols()["volumes"][0][0][1]
            results["tmax10_orig_slab1"]=op.tmaxthreshvols()["volumes"][0][0][3]
            results["core_orig_slab1"]=op.corethreshvols()["volumes"][0][0]        
            results["tmax6_orig_slab2"]=op.tmaxthreshvols()["volumes"][1][0][1]
            results["tmax10_orig_slab2"]=op.tmaxthreshvols()["volumes"][1][0][3]
            results["core_orig_slab2"]=op.corethreshvols()["volumes"][1][0]
            results["version_slab1"]='R46'
            results["version_slab2"]='R46'
            results["zcoverage_slab1"]=op.zcoverage_slab1
            results["zcoverage_slab2"]=op.zcoverage_slab2
            results["DateTime_slab1"]=op.SeriesDateTime_slab1
            results["DateTime_slab2"]=op.SeriesDateTime_slab2
            
        if os.path.isfile(folder + '/corelab.json'):
            fid=open(folder + '/corelab.json')
            ojson1=json.loads(fid.read())
            fid.close()
            results["tmax6_corr_total"]=ojson1["volumes"]["HYPOvol_corr"]
            results["tmax10_corr_total"]=ojson1["volumes"]["HYPOvol10_corr"]
            results["core_corr_total"]=ojson1["volumes"]["COREvol_corr"]
        
        
    #default to 4.5.1 including it's error handling in case of no files
    else:
        op=rapid451.RAPID451OP(folder)
        results["DateTime"]=op.SeriesDateTime
        results["tmax6_orig_total"]=op.tmaxthreshvols()["volumes"][1]
        results["tmax10_orig_total"]=op.tmaxthreshvols()["volumes"][3]
        results["core_orig_total"]=op.corethreshvols()["volumes"][0]
        results["errormsg"]=op.errormessage
        results["statuscode"]=op.statuscode
        results["modality"]=op.modality
        results["version_slab1"]='R451'
        results["zcoverage"]=op.zcoverage
        if os.path.isfile(folder + '/corelab.json'):
            fid=open(folder + '/corelab.json')
            ojson1=json.loads(fid.read())
            fid.close()
            results["tmax6_corr_total"]=ojson1["volumes"]["HYPOvol_corr"]
            results["tmax10_corr_total"]=ojson1["volumes"]["HYPOvol10_corr"]
            results["core_corr_total"]=ojson1["volumes"]["COREvol_corr"]


       
    return results

def addslabs(volumedict):
    
    if volumedict["tm6_slab1_orig"] > -1 and volumedict["core_slab1_orig"] > -1 and volumedict["tm6_slab2_orig"] > -1 and volumedict["core_slab2_orig"] > -1:
        volumedict["tmax6_orig_total"] =  volumedict["tm6_slab1_orig"] + volumedict["tm6_slab2_orig"]
        volumedict["tmax10_orig_total"] =  volumedict["tm10_slab1_orig"] + volumedict["tm10_slab2_orig"]
        volumedict["core_orig_total"] =  volumedict["core_slab1_orig"] + volumedict["core_slab2_orig"]
        
    elif volumedict["tm6_slab1_orig"] > -1 and volumedict["tm6_slab2_orig"] <= -1 and volumedict["core_slab1_orig"] > -1 and volumedict["core_slab2_orig"] <= -1 :
        volumedict["tmax6_orig_total"] =  volumedict["tm6_slab1_orig"]
        volumedict["tmax10_orig_total"] =  volumedict["tm10_slab1_orig"]
        volumedict["core_orig_total"] =  volumedict["core_slab1_orig"] 
        
    elif volumedict["tm6_slab2_orig"] > -1 and volumedict["tm6_slab1_orig"] <= -1 and volumedict["core_slab2_orig"] > -1 and volumedict["core_slab1_orig"] <= -1 :
        volumedict["tmax6_orig_total"] =  volumedict["tm6_slab2_orig"]
        volumedict["tmax10_orig_total"] =  volumedict["tm10_slab2_orig"]
        volumedict["core_orig_total"] =  volumedict["core_slab2_orig"] 
        
    else:
        volumedict["tmax6_orig_total"] =  -1
        volumedict["tmax10_orig_total"] =  -1
        volumedict["core_orig_total"] =  -1
        
    if volumedict["tm6_slab1_corr"] > -1 and volumedict["core_slab1_corr"] > -1 and volumedict["tm6_slab2_corr"] > -1 and volumedict["core_slab2_corr"] > -1:       
        volumedict["tmax6_corr_total"] =  volumedict["tm6_slab1_corr"] + volumedict["tm6_slab2_corr"]
        volumedict["tmax10_corr_total"] =  volumedict["tm10_slab1_corr"] + volumedict["tm10_slab2_corr"]
        volumedict["core_corr_total"] =  volumedict["core_slab1_corr"] +volumedict["core_slab2_corr"]
        
    elif volumedict["tm6_slab1_corr"] > -1 and volumedict["tm6_slab2_corr"] <= -1 and volumedict["core_slab1_corr"] > -1 and volumedict["core_slab2_corr"] <= -1 :
        volumedict["tmax6_corr_total"] =  volumedict["tm6_slab1_corr"] 
        volumedict["tmax10_corr_total"] =  volumedict["tm10_slab1_corr"] 
        volumedict["core_corr_total"] =  volumedict["core_slab1_corr"] 
        
    elif volumedict["tm6_slab2_corr"] > -1 and volumedict["tm6_slab1_corr"] <= -1 and volumedict["core_slab2_corr"] > -1 and volumedict["core_slab1_corr"] <= -1 :
        volumedict["tmax6_corr_total"] =  volumedict["tm6_slab2_corr"]
        volumedict["tmax10_corr_total"] = volumedict["tm10_slab2_corr"]
        volumedict["core_corr_total"] =  volumedict["core_slab2_corr"]
        
    else:
        volumedict["tmax6_corr_total"] =  -1
        volumedict["tmax10_corr_total"] = -1
        volumedict["core_corr_total"] =  -1
        
    if volumedict["slab1_zcov"] > -1 and volumedict["slab2_zcov"] > -1:     
        volumedict["total_zcov"] =  volumedict["slab1_zcov"] + volumedict["slab2_zcov"]

    elif volumedict["slab1_zcov"] > -1 and volumedict["slab2_zcov"] <= -1:
        volumedict["total_zcov"] =  volumedict["slab1_zcov"]
        
    elif volumedict["slab1_zcov"] <= -1 and volumedict["slab2_zcov"] > -1:
        volumedict["total_zcov"] =  volumedict["slab2_zcov"]
        
    else:
        volumedict["total_zcov"] =  -1
        
    
    

    #check which configuration of valid slabs we have
    
    #both slabs valid
   ### if (voldict["tm6_slab1_orig"]>-1 and voldict["tm6_slab2_orig"])....
    
    #both slabs invalid
    
    #slab 1 invalid
    
    #slabs 2 invalid
    return volumedict

    
def get_volumes(folder):
    volumedict={'Patient_ID': -1, 'BLorFU':-1,'modal':'NA','tm6_slab1_orig':-1,'tm6_slab2_orig':-1,'tm10_slab1_orig':-1,'tm10_slab2_orig':-1,'core_slab1_orig':-1,'core_slab2_orig':-1,
                             'tm6_slab1_corr':-1,'tm6_slab2_corr':-1,'tm10_slab1_corr':-1,'tm10_slab2_corr':-1,'core_slab1_corr':-1,'core_slab2_corr':-1,
                             'number_of_slabs':-1,'slab1error':'','slab2error':'','slab1_zcov':-1,'slab2_zcov':-1,'total_zcov':-1,'slab1_time':-1,'slab2_time':-1,
                             'version_slab1':-1,'version_slab2':-1,
                             'tmax6_orig_total':-1,'tmax10_orig_total':-1,'core_orig_total':-1,
                             'tmax6_corr_total':-1,'tmax10_corr_total':-1,'core_corr_total':-1}   
     #error codes are conveyed with negative integers. -1 = not found, -2 RAPID failed 
     
     #we need to iterate any *_use folder that is present
     
    usefolders=get_usefolders(folder) #will give CTP1 and CTP2 in order if CTP
   
    print(usefolders) 
   
    
    assert(len(usefolders)<3)
     
    
    
    
    if len(usefolders)>0:          #so this can be 4.6. single/dual  or 4.5.1 first and only slab or first of 2 slabs
       
        results=rapidX(usefolders[0])
        
        #if single slab (4.5.1 or 4.6 single slab) then just assign total to slab1 
        if (results["version_slab1"]=='R451' or results["version_slab1"]=='R46') and len(usefolders)>0:
            volumedict["tm6_slab1_orig"]=results["tmax6_orig_total"]
            volumedict["tm10_slab1_orig"]=results["tmax10_orig_total"]
            volumedict["core_slab1_orig"]=results["core_orig_total"]
        
            volumedict["tm6_slab1_corr"]=results["tmax6_corr_total"]
            volumedict["tm10_slab1_corr"]=results["tmax10_corr_total"]
            volumedict["core_slab1_corr"]=results["core_corr_total"]
            volumedict["slab1error"]=results["errormsg"]
            volumedict["slab1_time"]=results["DateTime"]
            volumedict["modal"]=results["modality"]
            volumedict["number_of_slabs"]=1
            volumedict["version_slab1"]=results["version_slab1"]
            volumedict["slab1_zcov"]=results["zcoverage"]
     
        #if dual slab (4.6) then just assign so each of the slabs (tm6_slab1_orig, tm6_slab2_orig etc etc) AND sum them 
        
        if results["numberofslabs"]==2 and results["version_slab2"]=='R46':
         
            volumedict["tm6_slab1_orig"]=results["tmax6_orig_slab1"]
            volumedict["tm10_slab1_orig"]=results["tmax10_orig_slab1"]
            volumedict["core_slab1_orig"]=results["core_orig_slab1"]
            volumedict["tm6_slab2_orig"]=results["tmax6_orig_slab2"]
            volumedict["tm10_slab2_orig"]=results["tmax10_orig_slab2"]
            volumedict["core_slab2_orig"]=results["core_orig_slab2"]
        
            volumedict["tm6_slab1_corr"]=results["tmax6_corr_total"]
            volumedict["tm10_slab1_corr"]=results["tmax10_corr_total"]
            volumedict["core_slab1_corr"]=results["core_corr_total"]
            volumedict["slab1error"]=results["errormsg"]
            #volumedict["slab1_zcov"]=results1[""]
            volumedict["slab1_time"]=results["DateTime_slab1"]
            volumedict["slab2_time"]=results["DateTime_slab2"]
            volumedict["modal"]=results["modality"]
            volumedict["number_of_slabs"]=results["numberofslabs"]
            volumedict["version_slab1"]=results["version_slab1"]   
            volumedict["version_slab2"]=results["version_slab2"] 
            volumedict["slab1_zcov"]=results["zcoverage_slab1"]
            volumedict["slab2_zcov"]=results["zcoverage_slab2"]
        
    if len(usefolders)==2:     # 2 slabs?
       
        results=rapidX(usefolders[1])
        volumedict["tm6_slab2_orig"]=results["tmax6_orig_total"]
        volumedict["tm10_slab2_orig"]=results["tmax10_orig_total"]
        volumedict["core_slab2_orig"]=results["core_orig_total"]
        volumedict["tm6_slab2_corr"]=results["tmax6_corr_total"]
        volumedict["tm10_slab2_corr"]=results["tmax10_corr_total"]
        volumedict["core_slab2_corr"]=results["core_corr_total"]
        volumedict["slab2error"]=results["errormsg"]
#        volumedict["slab1_zcov"]=results1["zcoverage_slab1"]
        volumedict["slab2_time"]=results["DateTime"]
        volumedict["modal"]=results["modality"]
        volumedict["number_of_slabs"]=2
        results["version_slab2"]='R451'
        volumedict["version_slab1"]=results["version_slab1"]
        volumedict["version_slab2"]=results["version_slab2"]
        volumedict["slab2_zcov"]=results["zcoverage"]
              
    #now sum the slabs
    if len(usefolders)==1 and not volumedict["number_of_slabs"]==2 :
        volumedict["tmax6_orig_total"] =  volumedict["tm6_slab1_orig"]
        volumedict["tmax10_orig_total"] =  volumedict["tm10_slab1_orig"]
        volumedict["core_orig_total"] =  volumedict["core_slab1_orig"]
        
        volumedict["tmax6_corr_total"] =  volumedict["tm6_slab1_corr"]
        volumedict["tmax10_corr_total"] =  volumedict["tm10_slab1_corr"]
        volumedict["core_corr_total"] =  volumedict["core_slab1_corr"]
        
        volumedict["total_zcov"]=volumedict["slab1_zcov"]
       
    if len(usefolders)==2 or (volumedict["number_of_slabs"]==2 and volumedict["version_slab2"]=='R46'):
        volumedict=addslabs(volumedict) 
       

    return volumedict



    


#MAIN

#webdcu_corevols=xlsx.xlsx('/Users/amar/Desktop/webdcuvolumes_test.xlsx')
webdcu_corevols=xlsx.xlsx('/Users/amar/Desktop/Corevolumedata_6_13_17.xlsx')
#webdcu_corevols=xlsx.xlsx('/Users/amar/Desktop/Mismatchclass/IMAGINGDATA_CTP_MRP_23JUN2017_updated.xlsx')

#perfusion_output_folder='/Users/amar/Desktop/testcases_stanfordcleanup/results_r45/'
#perfusion_output_folder='/Volumes/RAPID_PROCESSING/D3_Volumes_pre_correction/'

perfusion_output_folder='/Volumes/RAPID_PROCESSING/proc_rapid45_20cases/'


compareBLcore=[[] for i in range(4)]
i=0
#subjectid=webdcu_corevols["zSubjectID"]
#BLorFU=webdcu_corevols["BL_FU"]
#
#scandate=webdcu_corevols["SCAN_DT"]
#scandatetime_webdcu=[]
#scanhour=webdcu_corevols["SCANHR"]
#scanminute=webdcu_corevols["SCANMIN"]
dict={}
#for i in range(len(scandate)):
#    year, month, day, hour, minute, second = xlrd.xldate_as_tuple(int(scandate[i]), 0 )
#    scandatetime_webdcu.append(datetime.datetime(year,month,day,int(scanhour[i]),int(scanminute[i])))
#    print(scandatetime_webdcu[i])
#
#
#scandatetime_corelab_selected=[]
#time_elapsed=[]
blmrscans=0
blctscans=0
fumrscans=0
fuctscans=0
for cid in webdcu_corevols["Subject"]:
    
    blvols=get_volumes(perfusion_output_folder + cid + '/BL/')
    blvols["Patient_ID"]=cid
    blvols["BLorFU"]='BL'
#    print(blvols)
    with open('/Users/amar/Desktop/Mismatchclass/' + 'Volumes.txt', 'a') as f:
        print(blvols.values(),file=f)
        
    if blvols["modal"]=='MR':
        blmrscans=blmrscans+1
    if blvols["modal"]=='CT':
        blctscans=blctscans+1
    print(blvols["core_orig_total"]-float(webdcu_corevols["Ischemic core volume"][i]))
    compareBLcore[0].append(cid)
    compareBLcore[1].append(blvols["core_orig_total"])
    compareBLcore[2].append(float(webdcu_corevols["Ischemic core volume"][i]))
    compareBLcore[3].append(blvols["core_orig_total"]-float(webdcu_corevols["Ischemic core volume"][i]))
#    print(compareBLcore)
    fuvols=get_volumes(perfusion_output_folder + cid + '/FU/')
    fuvols["Patient_ID"]=cid
    fuvols["BLorFU"]='FU'
#    print(fuvols)
    with open('/Users/amar/Desktop/Mismatchclass/' + 'Volumes.txt', 'a') as f:
        print(fuvols.values(),file=f)
    i=i+1    
    
    if fuvols["modal"]=='MR':
        fumrscans=fumrscans+1
    if fuvols["modal"]=='CT':
        fuctscans=fuctscans+1
    
    
# for i in range(len(subjectid)):
#    if BLorFU[i] == 'BL' or BLorFU[i] == 'FU':
#    vols=get_volumes(perfusion_output_folder + '/' + subjectid[i] + '/' + BLorFU[i]) 
#    vols["Patient_ID"]=subjectid[i]
#    vols["BLorFU"]=BLorFU[i]
#    print(vols)
#    scandatetime_corelab=[]
#    scandatetime_corelab_slab1=vols["slab1_time"]
#    scandatetime_corelab_slab2=vols["slab2_time"]
#    if scandatetime_corelab_slab1==-1 or scandatetime_corelab_slab1=='NA' :
#        scandatetime_corelab.append(datetime.datetime(1111,1,1,1,1))
#    else:
#        scandatetime_corelab.append(datetime.datetime(int(scandatetime_corelab_slab1[0:4]),int(scandatetime_corelab_slab1[4:6]),int(scandatetime_corelab_slab1[6:8]), int(scandatetime_corelab_slab1[9:11]), int(scandatetime_corelab_slab1[11:13])))
#            
#    if scandatetime_corelab_slab2==-1 or scandatetime_corelab_slab2=='NA' :
#        scandatetime_corelab.append(datetime.datetime(1111,1,1,1,1))
#    else:
#        scandatetime_corelab.append(datetime.datetime(int(scandatetime_corelab_slab2[0:4]),int(scandatetime_corelab_slab2[4:6]),int(scandatetime_corelab_slab2[6:8]), int(scandatetime_corelab_slab2[9:11]), int(scandatetime_corelab_slab2[11:13])))
#        
#    scandatetime_corelab=sorted(scandatetime_corelab)
#    scandatetime_corelab_selected.append(scandatetime_corelab[1])
#    timediff=(scandatetime_webdcu[i]-scandatetime_corelab_selected[i])
#    time_elapsed.append(timediff.total_seconds()/(60*60))
#    dict={'scandatetime_webdcu':scandatetime_webdcu[i],'scandatetime_corelab_selected':scandatetime_corelab_selected[i],'time_elapsed':time_elapsed[i]}
#    print(dict.values())
#    print(scandatetime_webdcu[i])
#    print(scandatetime_corelab_selected[i])
#    print(time_elapsed[i])
        

    
    
    
        
        

    
    
    

    
    

    
    
    
    
    
    
    
    
    
    
    