#include "sc_itkimporter.h"

#include "itkImage.h"
#include "itkImageFileReader.h"
#include <QString>
#include <QDir>
#include <QRegularExpressionMatch>
#include <QRegularExpression>
#include <QDebug>

sc_itkimporter::sc_itkimporter()
{
    isinit=0;





}

sc_itkimporter::~sc_itkimporter()
{
    if (isinit)
    {    delete buffer; std::cout << "deleted buffer!" << std::endl; isinit=0; };

}



bool sc_itkimporter::readFiles(std::string mystr)
{


    QString myqstr=QString::fromStdString(mystr);



    QRegularExpression re("^.*/");
    QRegularExpressionMatch match = re.match(myqstr);
    QString dir;
    if (match.hasMatch()) {
        dir = match.captured(0);
    }


    //QString mystr("/home/sorenc/CODE/rapid_4_6/source/backend/build-perf_mismatch-Desktop_Qt_5_5_1_GCC_64bit-Default/");

    QDir focusdir(dir);
    focusdir.setNameFilters(QStringList()<<"post_volume_slab0_band0_timepoint*mhd");
    QStringList fileList = focusdir.entryList();

//    //prepend path..
    for (int k=0; k<fileList.size(); k++)
    {
        fileList[k]=dir+fileList[k];
    }



    itk::ImageIOBase::Pointer imageIO =
            itk::ImageIOFactory::CreateImageIO(
                fileList[0].toStdString().c_str(), itk::ImageIOFactory::ReadMode);
    if( !imageIO )
    {
        std::cerr << "Could not CreateImageIO for: " << fileList[0].toStdString() << std::endl;
        return EXIT_FAILURE;
    }

  //  std::cout << imageIO->GetComponentType() << std::endl;
    imageIO->SetFileName(fileList[0].toStdString().c_str());
    imageIO->ReadImageInformation();

    dims[0]= imageIO->GetDimensions(0);
    dims[1]= imageIO->GetDimensions(1);
    dims[2]= imageIO->GetDimensions(2);
    dims[3]= fileList.size();
    if (imageIO->GetComponentType()==itk::ImageIOBase::SHORT)
    {
        typedef itk::Image<short,3> shortimg;
        typedef  itk::ImageFileReader<shortimg> ReaderType;
        //size_t npixels_alloc=imageIO->GetImageSizeInPixels()*filelist.size();
        int nbytes_per_file=imageIO->GetImageSizeInBytes();

        buffer=new char[nbytes_per_file*fileList.size()];
       // buffer[1]=10;
        isinit=1;
        imageIO->Read(static_cast<void *>(buffer+0));

        //int pixels=imageIO->GetImageSizeInPixels();
        for (int k=1; k<fileList.size() ; k++)
        {
            //imageIO->SetFileName(filelist[k].toStdString().c_str());
            //imageIO->ReadImageInformation();
            ReaderType::Pointer reader = ReaderType::New();

            reader->SetFileName(fileList[k].toStdString().c_str());
            reader->Update();

            short* ptr=reader->GetOutput()->GetBufferPointer();


            memcpy( static_cast<void*>(buffer+k*nbytes_per_file), static_cast<void*>(ptr), nbytes_per_file);



//            imageIO->UpdateOutputData();
//        imageIO->Read(reinterpret_cast<void *>(buffer+k*nbytes_per_file));
//            std::cout <<  "read image into offset " << k*nbytes_per_file << std::endl;

//            int max=0;
//            for (int p=0; p<pixels; p++)
//            {
//                int cval=reinterpret_cast<short*>(buffer)[p];
//                 if (cval>max)
//                         max=cval;
//            }


             //std::cout << "max was "  << max << std::endl;
        }


       std::cout << "done reading "  << fileList.size() <<  " files" << std::endl;

       // std::cout << imageIO->GetDimensions(0) << std::endl;
    }


    return 0;



}

//char *sc_itkimporter::getBuffer()
//{
//    return buffer;
//}


short *sc_itkimporter::getBuffer()
{
    return reinterpret_cast<short*>(buffer);
}

int* sc_itkimporter::getDims()
{
    return &dims[0];
}



