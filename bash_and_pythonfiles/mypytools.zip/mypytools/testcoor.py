#import threading

import numpy as np
import matplotlib.pyplot as plt
plt.show()
import scutils.io.mhdread as mhdread
import scutils.io.rapidbinread as rapidbinread
import scutils.imquant.framecorr as framecorr
 
newmat=mhdread.readmhd("/home/sorenc/CODE/rapid_4_6/source/backend/build-perf_mismatch-Desktop_Qt_5_5_1_GCC_64bit-Default/post_volume_slab0_band0_timepoint*mhd")

#FILE ID
binfile = "/home/sorenc/102023_20130810T230705_CT_SLABA/102023_20130810_2312_motionCorrectedImportedData.bin"
oldmat=rapidbinread.rapidbinread(binfile)

oldmat[oldmat>400]=400
oldmat[oldmat<-80]=-80


oldcorr=framecorr.framecorr(oldmat,2)
newcorr=framecorr.framecorr(newmat,2)

plt.plot(range(len(oldcorr)),oldcorr,'r',range(len(oldcorr)),newcorr,'b')
plt.show()
#so old corr is better it seems. How can this be?  Is there a scaling issue etc?
newmat.min()
newmat.max()
oldmat.min()
oldmat.max()


oldframe=oldmat[:,:,4,5]
newframe=newmat[:,:,4,5]

plt.imshow( np.hstack( (oldframe, newframe)).T,cmap='gray',interpolation="nearest",origin="upper")
plt.show()


plt.imshow( (oldframe-newframe).T,cmap='gray',interpolation="nearest",origin="upper")
plt.colorbar()
plt.show()


#would liek to be able to surfer4d(oldframe-newframe)

#t=cy.pyShort()  #create oader instance
#mystr="/home/sorenc/CODE/rapid_4_6/source/backend/build-perf_mismatch-Desktop_Qt_5_5_1_GCC_64bit-Default/post_volume_slab0_band0_timepoint*mhd"
#t.readFiles(mystr)
#        #set prefix and load
#mymat=t.getNPmat()  #grab the data 
#
#mymat.max()
#
#
##now get the correlations
#mycorr=np.zeros((mymat.shape[3]),dtype=np.float32)
#img1=mymat[:,:,:,2]
#for k in range(mymat.shape[3]):
#    img2=mymat[:,:,:,k]
#    print np.corrcoef(img1.flatten(),img2.flatten() )
#    mycorr[k]= np.corrcoef(img1.flatten(),img2.flatten())[1][0]
#
#plt.figure
#plt.plot(mycorr)
#

#
#import ctypes
#from ctypes import util
#ctypes.CDLL(util.find_library('GL'), ctypes.RTLD_GLOBAL)
#ctypes.CDLL(util.find_library('glib-2'), ctypes.RTLD_GLOBAL)
#ctypes.CDLL(util.find_library('gobject-2'), ctypes.RTLD_GLOBAL)
#ctypes.CDLL(util.find_library('libXext'), ctypes.RTLD_GLOBAL)
#a=cy.pyA()
#a.pyGUI()
#t# = threading.Thread( target=a.pyGUI ) 
#t.daemon=False
#t.start()
