# -*- coding: utf-8 -*-
"""
Created on Sun Mar 20 20:49:38 2016

@author: sorenc
"""
import sys
import os.path
import rapid451
import rapid46
import numpy as np
import matplotlib.pyplot as plt
import numpy.matlib
import matplotlib.image as mpimg
import datetime
import json

lst=open("/home/sorenc/RAPID46_TEST_OUTPUT/allcases.lst","r").read().rstrip()
lst=lst.split("\n")


#lst=lst[0:20]
#lets prep some containers for output
#
processing_completed_mat=np.zeros((2,2),dtype=np.uint32)

tmaxarray=np.zeros((2,len(lst)),dtype=np.float)*np.nan
corearray=np.zeros((2,len(lst)),dtype=np.float)*np.nan
modalarray=np.zeros((2,len(lst)),dtype=np.uint8)*np.nan #2 rows serve as sanity check

imagesV1summary=[]
imagesV2summary=[]
imagesV1aifplot=[]
imagesV2aifplot=[]
imagesV1aifloc=[]
imagesV2aifloc=[]
imagesV1allpng=[]
imagesV2allpng=[]


corrs={}
field=[]
ipat=0;
IDs=[]

#TODO read in filters from a spread sheet. Filters can be:
#artefact 4.5.1
#SWIFT PRIME
#SWIFT PRIME REPERF ONLY


#TODO need to iterate over SP cases again to fill in artefact correctly

failure_mat=np.zeros((2,len(lst)),dtype=np.uint8)*np.nan  # [v1 ; v2]  failure coding
comparing=["v1","v2"]

zz=0
for iline in lst:
    print zz
    zz=zz+1
    dname=os.path.dirname(iline)
    fname=os.path.splitext(os.path.basename(iline))[0]
    opfoldername=dname+"_"+fname
    print opfoldername
    
    
    v1=rapid451.RAPID451OP("/home/sorenc/RAPID451_TEST_OUTPUT/" + opfoldername,False)

    v2=rapid46.RAPID46OP("/home/sorenc/RAPID46_TEST_OUTPUT/" + opfoldername,False)
    IDs.append(opfoldername)
   #if v2.status():   #0 ok, 1 other failure/missing files
    #    print v2
    #else:
    #    print "OK"
    #CT 1 MR 0
    modalarray[0,ipat]=1 if v1.modality=='CT' else 0
    modalarray[1,ipat]=1 if v2.modality=='CT' else 0
    #imagesV1.append([])
    #imagesV2.append([])    
    field.append(v1.fieldstrength)
    corrs[opfoldername]={"v1corr":v1.corr ,"v2corr":v2.corr ,"v2json_pre_corr":v2.json_corr_pre,"v2json_post_corr":v2.json_corr_post}
    #corrs.append([ v1.corr,v2.corr,v2jsoncorr   ])    
    failure_mat[:,ipat] = [v1.status(), v2.status()]  
    
    
    tmaxarray[0,ipat]=v1.tmaxthreshvols()["volumes"][1]
    tmaxarray[1,ipat]=v2.tmaxthreshvols()["volumes"][1]

    corearray[0,ipat]=v1.corethreshvols()["volumes"][0]     
    corearray[1,ipat]=v2.corethreshvols()["volumes"][0]  
    
    
    imagesV1summary.append(v1.summaryimg)
    imagesV2summary.append(v2.summaryimg)    
    
    imagesV1aifplot.append(v1.aifcurve)
    imagesV2aifplot.append(v2.aifcurve)        
    
    
    imagesV1aifloc.append(v1.aifloc)
    imagesV2aifloc.append(v2.aifloc)        
    
    imagesV1allpng.append(v1.allpng)
    imagesV2allpng.append(v2.allpng)       
    
    
    
    ipat=ipat+1
#    if v1.status()==0 and v2.status()==0:
#        
#        print v1.tmaxthreshvols()["volumes"]
#        print v2.tmaxthreshvols()["volumes"]
#        processing_completed_mat[0,0]=processing_completed_mat[0,0]+1
#        tmaxarray[0,ipat]=v1.tmaxthreshvols()["volumes"][1]
#        tmaxarray[1,ipat]=v2.tmaxthreshvols()["volumes"][1]
#
#        corearray[0,ipat]=v1.corethreshvols()["volumes"][0]     
#        corearray[1,ipat]=v2.corethreshvols()["volumes"][0]  
#        
#        images[ipat][0]=v1.images
#        images[ipat][1]=v2.images
#        
#    elif v1.status()==0 and v2.status()==1:
#        processing_completed_mat[0,1]=processing_completed_mat[0,1]+1           #need to also harvest volumes from version that worked in these two partial success cases
#    elif v1.status()==1 and v2.status()==0: 
#        processing_completed_mat[1,0]=processing_completed_mat[1,0]+1
#    elif v1.status()==1 and v2.status()==1: 
#        processing_completed_mat[1,1]=processing_completed_mat[1,1]+1

    
    
  
#print "Both version processed %u cases" % processing_completed_mat[0,0]  
#print "Both versions agreed not to process %u cases" % (processing_completed_mat[1,1]  )
#print "v1 processed %u case%s where v2 had no output" % (processing_completed_mat[0,1],"" if processing_completed_mat[0,1]==1 else 's')  
#print "v2 processed %u case%s where v1 had no output" % (processing_completed_mat[1,0],'' if processing_completed_mat[1,0]==1 else 's')  
#  
#  
  
#lets package this up in a structure that can be used to port the analysis elsewhere.  

analysis={"IDs":IDs,"imagesV1aifloc":imagesV1aifloc,"imagesV2aifloc":imagesV2aifloc,
          "imagesV1summary":imagesV1summary,"imagesV2summary":imagesV2summary,
          "imagesV1aifplot":imagesV1aifplot,"imagesV2aifplot":imagesV2aifplot,
          "failure_mat":failure_mat.tolist(),"comparing":comparing,"imagesV1allpng":imagesV1allpng,
          "imagesV2allpng":imagesV2allpng,"tmaxarray":tmaxarray.tolist(),
          "corearray":corearray.tolist(),"modalarray":modalarray.tolist(),
          "fieldstrength":field}  
#,"corrs":corrs 





#grab all images collected and copy them into a special test folder
import shutil
import re
v1_op="/home/sorenc/TESTS/"+comparing[0]+"/"
v2_op="/home/sorenc/TESTS/"+comparing[1]+"/"
if os.path.exists(v1_op):
    shutil.rmtree(v1_op)
if os.path.exists(v2_op):
    shutil.rmtree(v2_op)
        
    
os.mkdir(v1_op)
os.mkdir(v2_op)


#copy in the images from the source folders

indx=0
for imlist in analysis["imagesV1allpng"]:  #iterate patient
    iimg=0    
    for cimg in imlist:    #iterate list of pngs per patient
            newname=re.sub("\/","_",cimg)
            newlocation=v1_op +newname
            print "cp "+cimg+" "+newlocation 
            shutil.copy(cimg,newlocation)
            analysis["imagesV1allpng"][indx][iimg]=comparing[0]+"/"+newname
        
            
            
            iimg=iimg+1
    indx=indx+1
         #create 
indx=0    

for imlist in analysis["imagesV2allpng"]:
    iimg=0   
    for cimg in imlist:
        newlocation=v2_op +re.sub("\/","_",cimg)
        print "cp "+cimg+" "+newlocation 
        shutil.copy(cimg,newlocation)
        analysis["imagesV2allpng"][indx][iimg]=comparing[1]+"/"+re.sub("\/","_",cimg)
        iimg=iimg+1
         #create 
    indx=indx+1


####Read in the 4.5.1 classification 
## we want to capture if the case had artefacts. We want this organized based on the ID list in analysis 
import csv
csvfile='/home/sorenc/CODE/mypytools/casenames.csv'
#csvfile="/home/sorenc/TESTS/assessment451.csv"
csvobj=csv.DictReader(open(csvfile))
myfieldnames=csvobj.fieldnames

dat=list(csvobj)


#the above contains ID and then the filters.

filternames=myfieldnames[1:]

myfilters_sheet={}
myfilters_out={}

for ifilter in filternames:
    currentvalues = [1 if r[ifilter] else 0 for r in dat]
    myfilters_sheet[ifilter]=currentvalues
    
sheetIDs = [r["ID"] for r in dat]
#artefact_tmax=np.zeros(len(lst),dtype=np.uint8)   #does not include failures
#artefact_aif=np.zeros(len(lst),dtype=np.uint8)   #does not include failures

#get the sheet indices for our IDs 
sheetindices=[]
for cID in analysis["IDs"]:  #make sure we follow the ID order+length from above
    sheetindices.append(sheetIDs.index(cID))   #will crash if ID was not in sheet but it is required to be
    #where is this in the original list
    #now append the filter status
 
#now get the correct filter values into our output filter array
for ifilter in filternames:
    currentfilter=[]
    for iINDX in sheetindices:
         currentfilter.append( myfilters_sheet[ifilter][iINDX] )       
         
    myfilters_out[ifilter]=currentfilter         
      
      
#analysis["artefact_tmax"]=artefact_tmax.tolist()    
#nalysis["artefact_aif"]=artefact_aif.tolist()     

#try writing as json

#parse into json for flot
#non artefact cases
allID=analysis["IDs"]
allcores_merged=[list(a) for a in zip( analysis["corearray"][0],analysis["corearray"][1])]
allhypo_merged=[list(a) for a in zip( analysis["tmaxarray"][0],analysis["tmaxarray"][1])]
isCT=analysis["modalarray"][0]


#allartefactTmax=analysis["artefact_tmax"]
#allartefactAIF=analysis["artefact_aif"]


#MR_ID_noartefact=[ a for (a,b,c) in zip(allID,allartefactTmax,isCT) if (b<1 and c<1) ]
#MR_core_noartefact=[ a for (a,b,c) in zip(allcores_merged,allartefactTmax,isCT) if (b<1 and c<1) ]
#MR_hypo_noartefact=[ a for (a,b,c) in zip(allhypo_merged,allartefactTmax,isCT) if (b<1 and c<1) ]

#CT_ID_noartefact=[ a for (a,b,c) in zip(allID,allartefactTmax,isCT) if (b<1 and c>0) ]
#CT_core_noartefact=[ a for (a,b,c) in zip(allcores_merged,allartefactTmax,isCT) if (b<1 and c>0) ]
#CT_hypo_noartefact=[ a for (a,b,c) in zip(allhypo_merged,allartefactTmax,isCT) if (b<1 and c>0) ]

#MR_ID_artefact=[ a for (a,b,c) in zip(allID,allartefactTmax,isCT) if (b>0 and c<1) ]
#MR_core_artefact=[ a for (a,b,c) in zip(allcores_merged,allartefactTmax,isCT) if (b>0 and c<1) ]
#MR_hypo_artefact=[ a for (a,b,c) in zip(allhypo_merged,allartefactTmax,isCT) if (b>0 and c<1) ]

#CT_ID_artefact=[ a for (a,b,c) in zip(allID,allartefactTmax,isCT) if (b>0 and c>0) ]
#CT_core_artefact=[ a for (a,b,c) in zip(allcores_merged,allartefactTmax,isCT) if (b>0 and c>0) ]
#CT_hypo_artefact=[ a for (a,b,c) in zip(allhypo_merged,allartefactTmax,isCT) if (b>0 and c>0) ]

#store images in dict by ID - this will make it easy to locate them using js

allIMGlocations=zip(analysis["imagesV1allpng"],analysis["imagesV2allpng"])

all_summaryimage_indices=  zip(analysis["imagesV1summary"],analysis["imagesV2summary"])
all_aifplot_indices=  zip(analysis["imagesV1aifplot"],analysis["imagesV2aifplot"])
all_aifloc_indices=  zip(analysis["imagesV1aifloc"],analysis["imagesV2aifloc"])

myjson={ 
    "all_cores":allcores_merged,
    "all_hypo":allhypo_merged,
    "myfilters":myfilters_out,    
    "allIDs":allID,
    "allIMGlocations":allIMGlocations,
    "all_summaryimage_indices":all_summaryimage_indices,
    "all_aifplot_indices":all_aifplot_indices,
    "all_aifloc_indices":all_aifloc_indices,
    "isCT":isCT
    }


with open('data.txt', 'w') as outfile:
    json.dump(myjson, outfile)







tid=datetime.datetime.now().strftime('%Y%d%mT%H%M%S')

tname=comparing[0]+"_vs_"+comparing[1]+"_"+tid 


exportname="/home/sorenc/TESTS/"+tname+".p"
import cPickle as pickle
fp=open(exportname, 'wb')
pickle.dump(analysis, fp)  

fp.close() 




#TODO let the DPI classes know the location of the files and make a little window that can show them!




#plt.plot([0,600],[0,600])    
#   
#plt.scatter(corearray[0,modalarray[0,:]<1  ],corearray[1,modalarray[0,:]<1])    
#plt.xlabel('4.5.1')
#plt.ylabel('4.6')
#plt.title("ADC core")
#plt.show()
#
#
#
#
#plt.plot([0,100],[0,100])    
#   
#plt.scatter(corearray[0,modalarray[1,:]==1  ],corearray[1,modalarray[1,:]==1])    
#plt.xlabel('4.5.1')
#plt.ylabel('4.6')
#plt.title("CBF core")
#plt.show()


#etc.

#same for v1. Could probably share a base class, but most of the content will be on-the-fly parsing that is 
#version specific so not much reuse and may not be worth it.

