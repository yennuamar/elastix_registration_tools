#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 23 15:37:53 2017

@author: sorenc
"""
import zipfile

def xlsx(fname):  #found this om SO and grabbed it...

    from xml.etree.ElementTree import iterparse
    z = zipfile.ZipFile(fname)
    strings = [el.text for e, el in iterparse(z.open('xl/sharedStrings.xml')) if el.tag.endswith('}t')]
    rows = []
    row = {}
    value = ''
    for e, el in iterparse(z.open('xl/worksheets/sheet1.xml')):
        #print el.attrib
        if el.tag.endswith('}v'): # <v>84</v>
            value = el.text
        if el.tag.endswith('}c'): # <c r="A3" t="s"><v>84</v></c>
            if el.attrib.get('t') == 's':
                value = strings[int(value)]
            letter = el.attrib['r'] # AZ22
            while letter[-1].isdigit():
                letter = letter[:-1]
            row[letter] = value
            value = ''
        if el.tag.endswith('}row'):
            rows.append(row)
            row = {}

    headers=rows[0]

    newrows=[]
    for cphantomrow in rows[1:]:
        rowdict={}
        for columnname in cphantomrow.keys():
            rowdict[ headers[columnname] ]=cphantomrow[columnname]
        newrows.append(rowdict)

    #lets organize variables into dicts with phantom name and variable as key
    vectordict={}
    for column in cphantomrow.keys():
        vectordict[headers[column]]=[]  
        for cphantomrow in rows[2:]:
            vectordict[headers[column]].append(cphantomrow[column])
             
    
    
    
    
    return vectordict



