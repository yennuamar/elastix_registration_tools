#!/usr/bin/python
print "hello!"

import scutils.io.mhdread as mhdread

reader=mhdread.readmhd("/home/sorenc/CODE/rapid_4_6/source/backend/build-perf_mismatch-Desktop_Qt_5_5_1_GCC_64bit-Default/post_volume_slab0_band0_timepoint*mhd")
mymat=reader.getNPmat()

print mymat.shape
