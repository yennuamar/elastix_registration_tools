#!/usr/bin/python
import sys
import subprocess
import re
import datetime
import glob
import time
import smtplib
from email.mime.text import MIMEText

FOLDERlocation='/carpathia/running_studies/D3/miniperf/DIGEST/'
exceptions=['RAPID-CCSR','RAPID-ClevelandClinic']

sitelist=glob.glob(FOLDERlocation+ "/RAPID-*")
warnatolderthanXminutes=25
        # @params lookbackminutes Include files newer than this 
present = time.time()
warnlist=[]
for sitefolder in sitelist:
    site=os.path.basename(sitefolder)
    age=(present-os.path.getmtime(sitefolder))/60;
    age_fullmin=('%.0f' % age).rstrip('0').rstrip('.')
    print sitefolder + " age is " + age_fullmin+ " minutes"
        
    if ( (age>warnatolderthanXminutes) and (not site in exceptions )  ):
        
         warnlist.append(site + " " + age_fullmin)

sendstr=''
for site in warnlist:
      sendstr=sendstr+site+"\n"  

emaillist=['sorenc@stanford.edu']
me="sorenc@stanford.edu"
you="sorenc@stanford.edu"
MIMEmsg = MIMEText(sendstr)   
MIMEmsg['Subject'] = 'Alive beacon warnings '
MIMEmsg['From'] = me
MIMEmsg['To'] = ",".join(emaillist)
          
            # Send the message via our own SMTP server, but don't include the
            # envelope header.
s = smtplib.SMTP('localhost')
s.sendmail(me, emaillist, MIMEmsg.as_string())
s.quit()            

  


