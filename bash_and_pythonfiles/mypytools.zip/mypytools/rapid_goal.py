# -*- coding: utf-8 -*-
"""
Created on Sun Mar 20 20:49:38 2016

@author: sorenc
"""
import sys
import os.path
import rapid451
import rapid46
import numpy as np
import matplotlib.pyplot as plt
import numpy.matlib
import matplotlib.image as mpimg

def analyze(dirname,testname):
    fp=open(dirname + testname +".p") 
    analysis = pickle.load(fp)
    tmaxarray=analysis["tmaxarray"]
    images=analysis["images"]
    corrs=analysis["corrs"]
    
    fig = plt.figure(1)
    ax = fig.add_subplot(111)
      
    plt.plot([0,600],[0,600])    
    plt.scatter(tmaxarray[0,:],tmaxarray[1,:])    
    plt.xlabel('4.5.1')
    plt.ylabel('4.6')
    plt.title("Tmax>6")
    
    
    
    fig2=plt.figure(2)
    IDref = fig2.suptitle('ID')
    
    fig3=plt.figure(3)
    IDref3 = fig3.suptitle('ID')
    
    
    
    def onclick(event):
        if event.inaxes:
            #print "%f,%f" % (event.xdata, event.ydata)
            #construct a vector to compare to the tmaxarray location
            mymat=numpy.matlib.repmat( np.mat([[event.xdata],[event.ydata]]),1,tmaxarray.shape[1])
            powermat=np.power(mymat-tmaxarray,2)        
            diffvec=np.power(np.sum(powermat,axis=0),0.5)
            #print diffvec[0:,]
            minpos=np.nanargmin(diffvec)
            print diffvec[0,minpos]
            if diffvec[0,minpos]<5:
                cID=IDs[minpos]
                #print IDs[minpos]
                xy=tmaxarray[:,minpos]
                #plt.figure(1)         
                #ax.annotate(IDs[minpos] , xy=xy, textcoords='data')
                #plt.text(xy[0],xy[1],IDs[minpos])                     
                #plt.draw()
                
                plt.figure(2)
                myimg=mpimg.imread(dirname+images[minpos][0][0])
                myimg1=mpimg.imread(dirname+images[minpos][1][0])
                plt.subplot(2,1,1)
                imgplot = plt.imshow(myimg,interpolation='nearest')     
                plt.axis('off')
                
                plt.subplot(2,1,2)
                imgplot1 = plt.imshow(myimg1,interpolation='nearest')
                
                #plt.suptitle(IDs[minpos])
                plt.axis('off')            
                IDref.set_text(cID)
                plt.draw()
                
                plt.figure(3)
                plt.subplot(2,2,1)
                plt.cla()          
                plt.plot( corrs[ cID ]["r451corr"] ,'b')
                plt.title("r451corr sc")   
                plt.ylim( 0.90, 1 ) 
                
                plt.subplot(2,2,2)
                plt.cla()          
                plt.plot( corrs[ cID ]["r46corr"] ,'b')
                plt.title("r46corr sc")   
                plt.ylim( 0.90, 1 ) 
                
                
                plt.subplot(2,2,3)
                plt.cla()          
                plt.plot( corrs[ cID ]["r46json_pre_corr"] ,'b')
                plt.title("r46json_pre_corr")   
                plt.ylim( 0.90, 1 ) 
                
                
                plt.subplot(2,2,4)
                plt.cla()          
                plt.plot( corrs[ cID ]["r46json_post_corr"] ,'b')
                plt.title("r46json_post_corr")   
                plt.ylim( 0.90, 1 )             
                
                
                plt.draw()
            #diffmat=np.power( np.sum(),0.5)
            #print diffmat.shape        
            
            
        
    fig.canvas.mpl_connect('button_press_event', onclick)



    plt.show()   




lst=open("/home/sorenc/RAPID46_TEST_OUTPUT/allcases.lst","r").read().rstrip()
lst=lst.split("\n")

#lst=lst[58:61]
#lets prep some containers for output
#
processing_completed_mat=np.zeros((2,2),dtype=np.uint32)

tmaxarray=np.zeros((2,len(lst)),dtype=np.float)*np.nan
corearray=np.zeros((2,len(lst)),dtype=np.float)*np.nan
modalarray=np.zeros((2,len(lst)),dtype=np.uint32)*np.nan #2 rows serve as sanity check
images=[]
corrs={}
field=[]
ipat=0;
IDs=[]

comparing=["R451","R46"]

zz=0
for iline in lst:
    print zz
    zz=zz+1
    dname=os.path.dirname(iline)
    fname=os.path.splitext(os.path.basename(iline))[0]
    opfoldername=dname+"_"+fname
    print opfoldername
    
    
    r451=rapid451.RAPID451OP("/home/sorenc/RAPID451_TEST_OUTPUT/" + opfoldername,True)

    r46=rapid46.RAPID46OP("/home/sorenc/RAPID46_TEST_OUTPUT/" + opfoldername,True)
    IDs.append(opfoldername)
   #if r46.status():   #0 ok, 1 other failure/missing files
    #    print r46
    #else:
    #    print "OK"
    #CT 1 MR 0
    modalarray[0,ipat]=1 if r451.modality=='CT' else 0
    modalarray[1,ipat]=1 if r46.modality=='CT' else 0
    images.append([[],[]])
    field.append(r451.fieldstrength)
    corrs[opfoldername]={"r451corr":r451.corr ,"r46corr":r46.corr ,"r46json_pre_corr":r46.json_corr_pre,"r46json_post_corr":r46.json_corr_post}
    #corrs.append([ r451.corr,r46.corr,r46jsoncorr   ])    
    print sys.getsizeof(corrs)
    if r451.status()==0 and r46.status()==0:
        
        print r451.tmaxthreshvols()["volumes"]
        print r46.tmaxthreshvols()["volumes"]
        processing_completed_mat[0,0]=processing_completed_mat[0,0]+1
        tmaxarray[0,ipat]=r451.tmaxthreshvols()["volumes"][1]
        tmaxarray[1,ipat]=r46.tmaxthreshvols()["volumes"][1]

        corearray[0,ipat]=r451.corethreshvols()["volumes"][0]     
        corearray[1,ipat]=r46.corethreshvols()["volumes"][0]  
        
        images[ipat][0]=r451.images
        images[ipat][1]=r46.images
        
    elif r451.status()==0 and r46.status()==1:
        processing_completed_mat[0,1]=processing_completed_mat[0,1]+1
    elif r451.status()==1 and r46.status()==0: 
        processing_completed_mat[1,0]=processing_completed_mat[1,0]+1
    elif r451.status()==1 and r46.status()==1: 
        processing_completed_mat[1,1]=processing_completed_mat[1,1]+1

    ipat=ipat+1
    
  
print "Both version processed %u cases" % processing_completed_mat[0,0]  
print "Both versions agreed not to process %u cases" % (processing_completed_mat[1,1]  )
print "R451 processed %u case%s where R46 had no output" % (processing_completed_mat[0,1],"" if processing_completed_mat[0,1]==1 else 's')  
print "R46 processed %u case%s where R451 had no output" % (processing_completed_mat[1,0],'' if processing_completed_mat[1,0]==1 else 's')  
  
  
  
#lets package this up in a structure that can be used to port the analysis elsewhere.  

analysis={"comparing":comparing,"processing_completed_mat":processing_completed_mat,"images":images,"tmaxarray":tmaxarray,"corearray":corearray,"modalarray":modalarray,"fieldstrength":field,"corrs":corrs}  
 

#grab all images collected and copy them into a special test folder
import shutil
import re
v1_op="/home/sorenc/TESTS/"+comparing[0]+"/"
v2_op="/home/sorenc/TESTS/"+comparing[1]+"/"
if os.path.exists(v1_op):
    shutil.rmtree(v1_op)
if os.path.exists(v2_op):
    shutil.rmtree(v2_op)
        
    
os.mkdir(v1_op)
os.mkdir(v2_op)

indx=0
for cpair in analysis["images"]:
    
    iimg=0    
    for cimg in cpair[0]:
            newlocation=v1_op +re.sub("\/","_",cimg)
            print "cp "+cimg+" "+newlocation 
            shutil.copy(cimg,newlocation)
            analysis["images"][indx][0][iimg]=comparing[0]+"/"+re.sub("\/","_",cimg)
            iimg=iimg+1
         #create 
    iimg=0   
    for cimg in cpair[1]:
        newlocation=v2_op +re.sub("\/","_",cimg)
        shutil.copy(cimg,newlocation)
        analysis["images"][indx][1][iimg]=comparing[1]+"/"+re.sub("\/","_",cimg)
        iimg=iimg+1
         #create 
    indx=indx+1
 
 
testname=comparing[0]+"_vs_"+comparing[1] 
exportname="/home/sorenc/TESTS/"+testname+".p"

import cPickle as pickle
fp=open(exportname, 'wb')
pickle.dump(analysis, fp)  

fp.close() 




#TODO let the DPI classes know the location of the files and make a little window that can show them!




#plt.plot([0,600],[0,600])    
#   
#plt.scatter(corearray[0,modalarray[0,:]<1  ],corearray[1,modalarray[0,:]<1])    
#plt.xlabel('4.5.1')
#plt.ylabel('4.6')
#plt.title("ADC core")
#plt.show()
#
#
#
#
#plt.plot([0,100],[0,100])    
#   
#plt.scatter(corearray[0,modalarray[1,:]==1  ],corearray[1,modalarray[1,:]==1])    
#plt.xlabel('4.5.1')
#plt.ylabel('4.6')
#plt.title("CBF core")
#plt.show()


#etc.

#same for r451. Could probably share a base class, but most of the content will be on-the-fly parsing that is 
#version specific so not much reuse and may not be worth it.

