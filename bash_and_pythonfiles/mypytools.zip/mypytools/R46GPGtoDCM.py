#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri May 19 15:04:45 2017

@author: sorenc
"""

import subprocess
import sys
import os
import re

import smtplib
from email.mime.text import MIMEText

#periodically run using flock. FLAOCK IS ASSUMED!
#identify completed GPGs and put them in a tmp folder
#uncompress them locally
#move all DICOM files to an incoming DICOM folder


def osexec(cmd):
    pid = subprocess.Popen(cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
    op = pid.communicate()
    #print pid.poll()
    return (op,pid.poll())
 

def email_exception(message,recipient):
    pass    

def get_GPGs(GPGsource):
    GPG_report={"status":1,"gpglist":[]}
    op=osexec("find " + GPGsource + " -type f | grep gpg$")   
    GPG_report["status"]=op[1]
    if not op[1]==0:
        return GPG_report
        
    GPGlist=op[0][0].rstrip().split("\n")    
    GPG_report["gpglist"]=GPGlist
    return GPG_report

def uncompress_GPGlist(gpglist,tmpfolder):
    gpg_report=[]
    for gpg in gpglist:
        gpgbname=os.path.basename(gpg)
        targetloc=tmpfolder + '/' + gpgbname
        assert(not os.path.isfile(targetloc)) #this should never happen
        stat0=osexec("cp " + gpg +" "+targetloc )
        assert(stat0[1]==0)
        stat=osexec("gpg2  --batch --passphrase 1SolitaireDeviceIsFor1Patient? --decrypt-files " + targetloc)           
        assert(stat[1]==0)
        
        targetloc_zip=targetloc[:-4]
        targetloc_zip_folder=targetloc_zip[:-4]
        assert(not os.path.isdir(targetloc_zip_folder ))
        stat1=osexec("mkdir " +targetloc_zip_folder)
        assert(stat1[1]==0)
        stat2=osexec("unzip -q -od "+  targetloc_zip_folder + " "+ targetloc_zip)  
        assert(stat2[1]==0)
        gpg_report.append(targetloc_zip_folder)
        
    return gpg_report
        
    
 
    
def transfer_DICOMs(DCMoutput,TMPfolder):
    #first get an overall output of the DICOM contents using dcmsort
    
    
    st=osexec("mkdir " + TMPfolder +"/DCM")
    assert(st[1]==0)
    statdcmcopy=osexec("cd  "+ TMPfolder + ";  find * -type f | grep dcm$ | while read f; do cp --backup=t -r --parents $f "+ TMPfolder +"/DCM/" + " ; done")    
    #print stat[0][0]

    #allfolders=" ".join(uncompression_report)
    dcm_report=''
    stat=osexec("dcmsort --dryrun " +TMPfolder+ "/DCM/")
    if stat[1]==0:
        optxt=stat[0][0]
        sorted_lst=optxt.rstrip().split("\n")
        sorted_lst.sort()
        
        opatient=''
        ostudy=''
        for iline in sorted_lst:
             regex='PatientID=(?P<patientid>[^,]*),StudyTime=(?P<studytime>[A-Z0-9]*),modality=(?P<modality>[^,]*),seriesdescription=(?P<seriesdescription>[^,]*),multiphase=(?P<multiphase>[^,]*),isophasic=(?P<isophasic>[^,]*),equidistant=(?P<equidistant>[^,]*),slices=(?P<slices>[^,]*),frames=(?P<frames>[^,]*),zstep=(?P<zstep>[^,]*).*'
             op=re.search(regex , iline.rstrip() )
             
             if  not op:
                 dcm_report=dcm_report+ "Unparsed " + iline
                 continue
            
             matchdict=op.groupdict()
             
             if matchdict["patientid"]!=opatient:
                 dcm_report=dcm_report+  matchdict["patientid"]
                 opatient=matchdict["patientid"]
                 
             if matchdict["studytime"]!=ostudy:
                 ostudy=matchdict["studytime"]
                 dcm_report=dcm_report+  "\t\t"+ostudy
             
             dcm_report=dcm_report+  "\t\t\t" + matchdict["modality"] + ","+    matchdict["seriesdescription"] + ",slices=" + matchdict["slices"]+ ",frames=" + matchdict["frames"]
    
    st=osexec("mv " + TMPfolder+ "/DCM/* " +DCMoutput+ "/" )         
             
    return dcm_report+ "\n"+statdcmcopy[0][1]           
        
    
    #now copy over the DICOMs to the DICOM folder. Assume all have .dcm extentions and maintain the hierachy

def move_GPGs(gpglist,GPGlongtermstorage):
    delete_list=[]
    for k in  gpglist:
        #print "mv --backup=t " + k+ " " +GPGlongtermstorage + "/"
        st=osexec("mv --backup=t " + k+ " " +GPGlongtermstorage + "/" )        
        assert(st[1]==0)
        delete_list.append(k)        
    return delete_list    


    
def email_DCMreport(dcmreport,emaillist):
     me="sorenc@stanford.edu"
     #you="sorenc@stanford.edu"
     MIMEmsg = MIMEText(dcmreport)  
     MIMEmsg['Subject'] = 'DICOM receive report '
     MIMEmsg['From'] = me
     MIMEmsg['To'] = ",".join(emaillist)
            
            # Send the message via our own SMTP server, but don't include the
            # envelope header.
     s = smtplib.SMTP('localhost')
     s.sendmail(me, emaillist, MIMEmsg.as_string())
     s.quit()

     
     
     
     
     
GPGsource='/home/sorenc/GPGtests/GPGin'
GPGtmp='/home/sorenc/GPGtests/TMP'
GPGlongtermstorage='/home/sorenc/GPGtests/GPGlongterm'
DCMoutput='/home/sorenc/GPGtests/DCMoutput'

#identify list of GPG files - copy to tmp


osexec("rm -rf " + GPGtmp +"/*" )
gpg_list=get_GPGs(GPGsource)

if not gpg_list["status"]==0:
    #email error
    sys.exit(1)

    
if len(gpg_list["gpglist"])==0:
    sys.exit(0)   

uncompressed_folders=uncompress_GPGlist(gpg_list["gpglist"],GPGtmp)  #running on asserts for exceptions..

DICOM_info=transfer_DICOMs(DCMoutput,GPGtmp)

#delete_list=move_GPGs(gpg_list["gpglist"],GPGlongtermstorage)


#st=osexec("find " +GPGsource + "/*" + " -type d -empty -delete" )
assert(st[1]==0)
st=osexec("rm -rf " + GPGtmp +"/*" )
assert(st[1]==0)
email_DCMreport(['sorenc@stanford.edu'])

#decomp + unzip to same folder. Keep unzipped folders in idexed
#identify DICOMs by extension and copy them with parent to a sync folder. this sync folder will only touch older than 10 minutes and not race the file

