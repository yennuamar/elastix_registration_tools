# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 15:50:20 2016

@author: sorenc
"""

import sqlite3
import datetime
import re
import os
import numpy as np
import subprocess
import gdcm

import xmlrpclib

taglist=['PatientName','Modality', 'InstanceNumber','PatientID' ,'PatientAge','PatientSex','StudyDate' ,'StudyTime', 'SeriesDescription', 'InstanceNumber', 'SeriesInstanceUID' , 'SeriesTime', 'SeriesDate' ]

def queryfile(pos):
#get standard tag values from file if DCM
  
    r = gdcm.Reader()
    r.SetFileName( pos )
    success = r.ReadSelectedTags(TAGVEC)
    op={};
    if not success:
        op["ISDICOM"]=0
        return op
    

    sf=gdcm.StringFilter()
    sf.SetFile(r.GetFile());
    tagdict={}
    for itag in range(len(TAGVEC)):
        #print sf.ToString(ctag)
        content=sf.ToString(TAGVEC[itag])
        content=re.sub('[^a-zA-Z0-9\.\-_]+','',content)
           
        if len(content)==0:
            content="NA"
        
        if taglist_sorted[itag]=="StudyTime":
            content=re.sub('\.[0-9]+','',content)
     
        tagdict[taglist_sorted[itag]]=content
    #regularize
    
  
    
    op["ISDICOM"]=1
    op["dict"]=tagdict
    return op


def osexec1(cmd):
    pid = subprocess.Popen(cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)  #the +p prepends the hierachy and makes sure the match below only takes lavel one occurences...
    op = pid.communicate()
    return (pid.poll(),op)

def filedict2png(seriesdict,location):
    ID=seriesdict["ID"]
    datelabel=seriesdict["datelabel"]
    #datetime=seriesdict["datetime"]    
    #seriesdesc=seriesdict["seriesdesc"]

    targetfolder=location + "/" + ID + "/" +datelabel +"/"
    osexec1("mkdir  -p "+ targetfolder)
    
    for ifile in seriesdict["urllist"]:
          targetname=os.path.basename(ifile) 
          targetname=re.sub('\.dcm','.png',targetname)
          osexec1("mkdir  -p "+ targetfolder)
          osexec1("dcmj2pnm +Wm +on " +ifile + " "+ targetfolder+targetname)
          
          
def retrieve_dicoms(ID,datelabel,seriesdesc,datetime,ZID,files):
    #create a subfolder for ID/datetime/seriesnumber and dump the dicoms there by rsyncing with imac
    
           
    #prep an export data structure that makes it easy to convert this to png
    filedict={}    
    filedict["ID"]=ID;    
    filedict["datelabel"]=datelabel    
    filedict["datetime"]=datetime
    filedict["seriesdesc"]=seriesdesc
    filedict["urllist"]=[]
    #work out the output folder name
    
    if not os.path.exists('/home/sorenc/RAPIDOSIRIX/'):
        osexec1("mkdir /home/sorenc/RAPIDOSIRIX/")        
    for k in files:
        loc=str( int(np.ceil(float(k[0]+1)/10000.0)*10000)) + "/" +str(k[0]) + ".dcm"
        print loc
 
        
        cmd="scp sorenc@imac:~/Documents/OsiriX*Data/DATABASE.noindex/" + loc + " tmp.dcm"
        op=osexec1(cmd)
        if not (op[0]==0):
            print "failed to retrieve " + loc
            print op[1]
            return
        #query for instancenumber  
        op=queryfile("tmp.dcm")
        assert(op["dict"]["PatientID"]==ID)
        instancenumber=op["dict"]["InstanceNumber"]
        
        #mrdict={"61_1":"Columns","61_10":"AIFVOFPlot","61_100":"AIFVOFlocation","61_2":"Core","61_3":"Summary","60_4":"Tmax","61_4":"Tmax","60_3":"Summary","60_2":"Core"}
        ctdict={"60_1":"Columns","61_1":"Columns","61_10":"AIFVOFPlot","60_10":"AIFVOFPlot","61_100":"AIFVOFlocation","61_2":"Core","61_3":"Summary","60_4":"Tmax","61_4":"Tmax","60_3":"Summary","60_2":"Core"} #turns out identical...
        #lets give this image a name
        series_instancenumber=ZID[-2]+ZID[-1]+"_"+instancenumber
        if op["dict"]["Modality"]=="CT":
            imagetype="CT_"+ctdict[series_instancenumber]         
        else:
            imagetype="MR_"+ ctdict[series_instancenumber]         
        
        seriesdatetime=op["dict"]["SeriesDate"] + "T" +op["dict"]["SeriesTime"] 
        opurl="/home/sorenc/RAPIDOSIRIX/" +ID+"_"+datelabel+"_"+datetime+"_"+ZID+"_" +imagetype+".dcm"      #"_"+re.sub(" ","_",seriesdesc)+
        #print opurl
        filedict["urllist"].append(opurl)
        osexec1("mv tmp.dcm " +opurl)
        
    return filedict
   
    
    
def regexp(expr, item):
    reg = re.compile(expr)
    return reg.search(item) is not None




#CREATE THE TAGVEC needed for querying individual files
singleton = gdcm.Global.GetInstance()
dicts = singleton.GetDicts()
d = dicts.GetPublicDict()

TAGVEC=gdcm.TagSetType()

for k in taglist:
    optag=gdcm.Tag()
    tagname=d.GetDictEntryByKeyword( k,optag )
    #print k
    if optag.GetGroup()==65535:
        sys.stderr.write("Fatal error - could not parse dictionary")
        exit(1)
    #ctag=gdcm.Tag(optag)
    TAGVEC.insert(optag)
taglist_sorted=[]
#now get a keywordlist in the same sorted order as TAGVEC
for k in TAGVEC:
    taglist_sorted.append(d.GetKeywordFromTag(k))
    





#get time of each CTP/PWI scan at BL and FU

server = Server("http://171.65.168.30:8080",verbose=False)

IDs=server.getPatientIDs()

#find studies with ROIs and prep for copy.
studies_to_retrieve=[]
for cid in IDs:
    studies=server.PatientIDtoStudies(  {"patientID": cid})    
    for istudy in studies:   
        series=server.StudyUIDtoSeries(  {"studyInstanceUID": istudy} )  
        for iseries in series:
            
            if iseries=='OsiriX Annotations SR' or iseries=='LOCALIZER' or iseries=='OsiriX ROI SR' or iseries=='PresentationStates':
                continue
            
            seriesinfo=server.DBWindowFind( {"request": "seriesInstanceUID == '" +  iseries +  "'", "table": "Series", "execute": "Nothing"})
            assert(len(seriesinfo["elements"]))==1
            #print seriesinfo["elements"][0]            
            if seriesinfo["elements"][0].has_key("name"):
                 if (seriesinfo["elements"][0]["name"][0:7]=='ROImask'):
                     print 'here'
                     studies_to_retrieve.append(istudy)



for istudy in studies_to_retrieve:
    #get image paths for these studies and copy them over using our own hierachy
    series=server.StudyUIDtoSeries(  {"studyInstanceUID": istudy} ) 
    for iseries in series:
          images=server.Seri
    
      

              

#get all studies with a BL or FU comment


#for each study, locate CTP 


#==============================================================================
# 
# 
#     for cid in IDs[0:10]:
#         studies=server.PatientIDtoStudies(  {"patientID": cid})    
#         for istudy in studies:
#             series=server.StudyUIDtoSeries(  {"studyInstanceUID": istudy} )    
#             
#             for iseries in series:
#                 print iseries
#                 
#                 
#                 if iseries=='OsiriX Annotations SR' or iseries=='LOCALIZER' or iseries=='OsiriX ROI SR' or iseries=='PresentationStates'::
#                     #seriesinfo=server.DBWindowFind( {"request": "seriesInstanceUID == '" +  iseries +  "'", "table": "Series", "execute": "Nothing"})
#                     #print seriesinfo["elements"]
#                     continue
#                 
#                 seriesinfo=server.DBWindowFind( {"request": "seriesInstanceUID == '" +  iseries +  "'", "table": "Series", "execute": "Nothing"})
#                 print seriesinfo["elements"][0]                
#                 print len(seriesinfo["elements"])
#                 if len(seriesinfo["elements"])>1:
#                     print seriesinfo["elements"]
#                     
#                 if seriesinfo["elements"][0].has_key("name"):
#                     #print seriesinfo["elements"][0]["seriesDescription"]   
#                     if (re.search('adc',seriesinfo["elements"][0]["name"],re.IGNORECASE) and not re.search('none',seriesinfo["elements"][0]["name"],re.IGNORECASE) ):
#                          print seriesinfo["elements"][0]["name"]   
#                          #print iseries
#                       #   t=server.SetComment2forSeries({"seriesInstanceUID": iseries , "Comment2":"ADC" } )
#                 
#                 
# 
# 
#==============================================================================
