# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 10:47:46 2016

@author: sorenc
"""
#from __future__ import print_function
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.text import Text
from matplotlib.image import AxesImage
import numpy as np
from numpy.random import rand

if 0:
    fig, ax = plt.subplots()
    ax.set_title('click on points', picker=True)
    ax.set_ylabel('ylabel', picker=True, bbox=dict(facecolor='red'))
    line, = ax.plot(rand(100), 'o', picker=5)

    def onpick1(event):
        print "%f,%f" % (event.xdata, event.ydata)
#        if isinstance(event.artist, Line2D):
#            thisline = event.artist
#            xdata = thisline.get_xdata()
#            ydata = thisline.get_ydata()
#            ind = event.ind
#            print 'X='+str(np.take(xdata, ind)[0]) # Print X point
#            print 'Y='+str(np.take(ydata, ind)[0]) # Print Y point

    fig.canvas.mpl_connect('motion_notify_event', onpick1)
    fig.show()
    
    
    
#lets create a work sheet based on the 451 output - this will be a starting point for reviewing source data and getting to a final classifiction of the 4.5.1 output  
#get a list of all cases.
#find out if the case is/is not in Tmax artefact and in VOF artefact     
import os
import re

p="/home/sorenc/JPEG_451/"
allraw=open("/home/sorenc/JPEG_451/allcases.lst").readlines()   
all=[]
no_output=[]

f=open('assessment451_dummy.csv','w')
f.writelines("ID,ARTEFACT_TMAX,ARTEFACT_AIF"+"\n")
someartefact={}
for line in allraw:
    all.append(re.sub("/","_",os.path.splitext(line.rstrip())[0]))

for ctest in all:
    mystr=ctest+","
     #check that file is in one of the two folders
    if os.path.exists(p+"ARTEFACT_TMAX/" + ctest+ ".png"):
        mystr=mystr+"1,"
        someartefact[ctest]=""
    elif os.path.exists(p+"NO_OR_MODEST_ARTEFACT_TMAX/" + ctest+ ".png"):
        mystr=mystr+"0,"        
    else:
        #print "fatal error " + ctest+ "  not found"       
        mystr=mystr+"-1,"
        
        #no_output.append(ctest)

    if os.path.exists(p+"ARTEFACT_AIF/" + ctest+ "_plot.png"):
        mystr=mystr+"1,"
        someartefact[ctest]=""
    elif os.path.exists(p+"NO_OR_MODEST_ARTEFACT_AIF/" + ctest+ "_plot.png"):
        mystr=mystr+"0,"        
    else:
        mystr=mystr+"-1,"
        #print "fatal error " + ctest+ "  not found"       

    print mystr
    f.writelines(mystr+"\n")
    
    
f.close() 


#list of who to review
for k in someartefact.keys():
    print k









   