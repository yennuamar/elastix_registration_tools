# -*- coding: utf-8 -*-
"""
Created on Fri Apr  1 14:54:44 2016

@author: sorenc
"""
import RPDjson
import os.path
import glob
import json
#import scutils.io.mhdread as mhdread
import scutils.imquant.framecorr as framecorr
import scutils.common as common

#add query of datetime
class RAPID46OP:
    def __init__(self,foldername,calccorr=False):  
        
        #corr from actual image files
        self.corr=[]    
        self.allpng=[]
        self.summaryimg=-1
        self.aifcurve=-1
        self.aifloc=-1
        self.SeriesDateTime='NA'
        self.numberofslabs=-1
        if calccorr:
            tps=glob.glob(foldername + "/post_volume_slab0_band0_timepoint*")
            if len(tps)>0:
                t=mhdread.readmhd(foldername + "/post_volume_slab0_band0_timepoint*")    #ISSUE: this creates an instance that holds the mat. this instance is not deleted until this RAPID46OP instance is deleted
                
                self.corr=framecorr.framecorr(t.getNPmat(),2)
                del t
            else:
                self.corr=[]
        
        #corr from json        
        opjson=foldername+"/post_afterMotionCorrection_slab0.json"   
        if os.path.isfile(opjson):
            fid=open(opjson,"r")
            dat=json.loads(fid.read())
            fid.close()
            self.json_corr_pre=dat["TimepointCorrelationBeforeMoCo"]
            self.json_corr_post=dat["TimepointCorrelationAfterMoCo"]
        else:        
            self.json_corr_pre=[]
            self.json_corr_post=[]
            
            
        jsonfile=foldername+"/output.json"
        if os.path.isfile(jsonfile):    #for zcoverage
            fid=open(jsonfile)
            self.voldict_outputjson=json.loads(fid.read())
            fid.close()
       
            try: 
                if self.voldict_outputjson['NumberOfPerfusionSlabs']==1:
                    numberofperfusionslabs=1 
                elif self.voldict_outputjson['NumberOfPerfusionSlabs']==2:
                    numberofperfusionslabs=2 
            except:
                numberofperfusionslabs=0 #onlydwicase
                
            if numberofperfusionslabs == 0 :
                self.numberofslices=self.voldict_outputjson['DICOMHeaderInfo']['DiffusionSeries'][0]['NumberOfSlices']
                self.slicethickness=self.voldict_outputjson['DICOMHeaderInfo']['DiffusionSeries'][0]['SliceThickness']
                self.zcoverage=self.numberofslices*float(self.slicethickness)
                
            if numberofperfusionslabs == 1 :                
                self.numberofslices=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][0]['NumberOfSlices']
                self.slicethickness=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][0]['SliceThickness']
                self.zcoverage=self.numberofslices*float(self.slicethickness)

            if numberofperfusionslabs == 2:
                self.numberofslices_slab1=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][0]['NumberOfSlices']
                self.slicethickness_slab1=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][0]['SliceThickness']
                self.numberofslices_slab2=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][1]['NumberOfSlices']
                self.slicethickness_slab2=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][1]['SliceThickness']
                self.zcoverage_slab1=self.numberofslices_slab1*float(self.slicethickness_slab1)
                self.zcoverage_slab2=self.numberofslices_slab2*float(self.slicethickness_slab2)
                self.zcoverage=self.zcoverage_slab1+self.zcoverage_slab2
                 
            try:
                if numberofperfusionslabs == 1:            
                    Seriesdate=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][0]['SeriesDate']
                    Seriestime=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][0]['SeriesTime']
                    self.SeriesDateTime=Seriesdate+ '_' +Seriestime
                elif numberofperfusionslabs == 0:    
                    Seriesdate=self.voldict_outputjson['DICOMHeaderInfo']['DiffusionSeries'][0]['SeriesDate']
                    Seriestime=self.voldict_outputjson['DICOMHeaderInfo']['DiffusionSeries'][0]['SeriesTime']
                    self.SeriesDateTime=Seriesdate+ '_' +Seriestime
                elif numberofperfusionslabs == 2: 
                    Seriesdate_slab1=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][0]['SeriesDate']
                    Seriestime_slab1=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][0]['SeriesTime']
                    self.SeriesDateTime_slab1=Seriesdate_slab1+ '_' +Seriestime_slab1
                    
                    Seriesdate_slab2=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][1]['SeriesDate']
                    Seriestime_slab2=self.voldict_outputjson['DICOMHeaderInfo']['PerfusionSeries'][1]['SeriesTime']
                    self.SeriesDateTime_slab2=Seriesdate_slab2+ '_' +Seriestime_slab2
            except:
                self.SeriesDateTime=-1
                self.SeriesDateTime_slab1=-1
                self.SeriesDateTime_slab2=-1
                
        measfile=foldername+"/measurements.json"
        if os.path.isfile(measfile):
            self.voldict=RPDjson.readJSON(measfile)
            self.numberofslabs=self.voldict["numberofslabs"]
            if self.voldict["returncode"]==0:
                self.foldername=foldername
                self.statuscode=bool(0)
                self.errormessage=""
                self.modality=self.voldict["coremodal"]
                if self.modality=='CT':
                    self.allpng=glob.glob(foldername+"/results/series*.jpg")
                    self.summaryimg=common.get_indx(self.allpng,".*series.*Mismatch.jpg")
                     
                    self.aifcurve=common.get_indx(self.allpng,".*series.*_AIF_VOF_Curves.jpg")
                    self.aifloc=common.get_indx(self.allpng,".*series.*_AIF_VOF_Locations.jpg")
                    
                else:
                    self.allpng=glob.glob(foldername+"/results/series*.jpg")
                    self.summaryimg=common.get_indx(self.allpng,".*series.*ADC_Tmax_based_Mismatch.jpg")
                    self.aifcurve=common.get_indx(self.allpng,".*series.*_AIF_VOF_Curves.jpg")
                    self.aifloc=common.get_indx(self.allpng,".*series.*_AIF_VOF_Locations.jpg")
                    
                return
            else:
                self.statuscode=bool(1)
                self.errormessage="Measurements.json is incomplete"
                self.modality=""   
                return
        else:       
            self.statuscode=bool(1)
            self.errormessage="No measurements.json available"
            self.modality=""
            self.voldict=RPDjson.get_no_voldict()
            return
        

                
    def modality(self):
        return self.modality
        
    def __str__(self):
        return self.errormessage        
        
    def status(self):
        return self.statuscode
    
    def tmaxthreshvols(self):
        return {"thresholds":self.voldict["tmaxthresholds"],"volumes":self.voldict["tmaxvolumes"]}
        
    def corethreshvols(self):
        return {"corethresholds":self.voldict["corethresholds"],"volumes":self.voldict["corevolumes"]}
    
    def thesholds(self):
        return 
    
    def zcoverage(self):
        return self.zcoverage
    
    def zcoverage_slab1(self):
        return self.zcoverage_slab1
    
    def zcoverage_slab2(self):
        return self.zcoverage_slab2
    
    
    


