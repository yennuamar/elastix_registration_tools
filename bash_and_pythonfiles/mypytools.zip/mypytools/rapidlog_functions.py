#!/usr/bin/python
import sys
import re
import os
import glob
import shutil
import datetime
import subprocess
from time import sleep
#fname = sys.argv[1]

#this script iterates over receive logs and makes a deidentified digest of what was received
SYNC=1
do_copy_maps=0
def osexec(cmd):
    pid = subprocess.Popen(cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)  #the +p prepends the hierachy and makes sure the match below only takes lavel one occurences...
    #op = pid.communicate()
    #print pid.poll()
    #return op
    
    
def osexec1(cmd):
    pid = subprocess.Popen(cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)  #the +p prepends the hierachy and makes sure the match below only takes lavel one occurences...
    op = pid.communicate()
    return (pid.poll(),op)

def getMMlogdigests(parentlogfolder,loglist):
    joblist=[]
    for k in loglist:
        fid1=open(parentlogfolder+"/"+k)
        mystr1=fid1.read()
        fid1.close()


        #ID
        ID=re.findall("[0-9]{8}_[0-9]{6}_[-]?[0-9]+_[A-Z0-9]+.*Module",os.path.basename(k))[0]
        #lines to get    
        #exeline=re.findall('/opt/rapid3/rapid.*$',mystr1,re.MULTILINE)   
        #TODO - deident exeline
        
        hd=re.search('Detected scanner.*(\nResampling|\nOutput)',mystr1,re.DOTALL)
        
        if hd==None:
            headerdigest="NO PWI detected"
        else:
            headerdigest=hd.group(0)
            
        
        #lets also get the header text
        PWIheaderfile=glob.glob(os.path.dirname(parentlogfolder+"/"+k)+ "/[0-9][0-9][0-9]_*_PWI_header.txt")
        if not PWIheaderfile:
            PWIheaderfile=glob.glob(os.path.dirname(parentlogfolder+"/"+k)+ "/[0-9][0-9][0-9]_*_CTP_header.txt")    
        
        DWIheaderfile=glob.glob(os.path.dirname(parentlogfolder+"/"+k)+ "/[0-9][0-9][0-9]_*_DWI_header.txt")
        if not DWIheaderfile:     
            DWIheaderfile=glob.glob(os.path.dirname(parentlogfolder+"/"+k)+ "/*_DWI_header.txt") #in some cases of phantoms the above DWI dump will not exist
            
        if not (PWIheaderfile or DWIheaderfile):
            continue
          
        if PWIheaderfile: 
            RAPIDID=re.findall("[0-9]{3}_A[0-9]{6}",os.path.basename(PWIheaderfile[0]))[0]  
        else:
            RAPIDID=re.findall("[0-9]{3}_A[0-9]{6}",os.path.basename(DWIheaderfile[0]))     
            if RAPIDID:
                RAPIDID=RAPIDID[0] 
            else:
                RAPIDID="IDEXTRACTIONERROR"
                print "ID extration error"
            
        #headerfile=glob.glob(os.path.dirname(parentlogfolder+"/"+k)+ "/[0-9][0-9][0-9]_*_header.txt")[0]  
        PWIlines=''
        DWIlines=''
        if PWIheaderfile:  
            fid1=open(PWIheaderfile[0])
            PWIlines=fid1.readlines()
            fid1.close()
        
        if DWIheaderfile:
            fid1=open(DWIheaderfile[0])
            DWIlines=fid1.readlines()
            fid1.close()
        
        maplocations=glob.glob(os.path.dirname(parentlogfolder+"/"+k)+ "/results/*png");
        
        #todo - change to DWI and PWI header
        joblist.append( {'RAPIDID':RAPIDID,'ID':ID,'header':headerdigest ,'PWIDICOM':PWIlines,'DWIDICOM':DWIlines,'maps':maplocations} )
        #lets get the image locations        
        
        #Detected scanner: until
        #Resampling imported data,
        #eventually we should build in if RAPID succeeded or not
    return joblist

def getcroninfo():
    op=osexec1('crontab -l')
    
    SITE=re.findall("(?<=SITE=)[a-zA-Z_-]*",op[1][0])
    if not len(SITE):
        SITE="PROBLEM WITH SITE NAME"
    else:
        SITE=SITE[0]
        
  
    RAPIDDATA=re.findall("(?<=RAPIDDATA=)[-_\/a-zA-Z0-9]*",op[1][0])
    if not len(RAPIDDATA):
        RAPIDDATA="PROBLEM WITH RAPID_DATE NAME"
    else:
        RAPIDDATA=RAPIDDATA[0]
     
    RAPID_DELETE_AFTER_DAYS=re.findall("(?<=RAPID_DELETE_AFTER_DAYS=)[0-9]*",op[1][0])
    if not len(RAPID_DELETE_AFTER_DAYS):
        RAPID_DELETE_AFTER_DAYS="PROBLEM WITH RAPID_DEL_AFTER_DAYS NAME"
    else:
        RAPID_DELETE_AFTER_DAYS=RAPID_DELETE_AFTER_DAYS[0]





    RAPID3_PATH=re.findall("(?<=RAPID3_PATH=)[-_\/a-zA-Z0-9]*",op[1][0])
    if not len(RAPID3_PATH):
        RAPID3_PATH="PROBLEM WITH RAPID_DATE NAME"
    else:
        RAPID3_PATH=RAPID3_PATH[0]



    #lets get the site ID which we can derive from the above
    configfile=RAPID3_PATH+"/local/"+SITE+"/config_instance.pl"
        
    fid1=open(configfile)
    mystr1=fid1.read()
    fid1.close()        
        
        
    ID=re.findall("\$RPD::inst{InstanceIDNr} = \"(?P<ID>[0-9]*)\"",mystr1)
    if not len(ID):
        SITEID="ISSUEWITHID"
    else:
        SITEID=ID[0]    
    croninfo={"SITE":SITE,"RAPIDDATA":RAPIDDATA,"RAPID_DELETE_AFTER_DAYS":RAPID_DELETE_AFTER_DAYS,"RAPID3_PATH":RAPID3_PATH,"SITEID":SITEID}     




    return croninfo


def getCAlogdigests(parentlogfolder,loglist):
    joblist=[]
    for k in loglist:
        


        #ID
        ID=re.findall("[0-9]{8}_[0-9]{6}_[-]?[0-9]+_[A-Z0-9]+.*Module",os.path.basename(k))[0]
        #lines to get    
        #exeline=re.findall('/opt/rapid3/rapid.*$',mystr1,re.MULTILINE)   
        #TODO - deident exeline
        
        #the serieslist appears to be the most valuable output for our purposes
        tmp=re.sub('logfile_|\.log','',k)        
        serieslistID=re.sub('_Rapid3_CatchAllModule','.series.list',tmp)        
        
        serieslistURL=parentlogfolder+serieslistID
        
        fid1=open(serieslistURL)
        mystr1=fid1.read()
        fid1.close()        
        
        #deidentify the date
        #headerdigest=re.sub('_2[0-9]{7}_','_01012000_',mystr1)  
        headerdigest=mystr1  
        hd=re.search('[0-9]{3}_A[0-9]{6}',mystr1,re.DOTALL)
        if hd==None:
            RAPIDID='NOTFOUND'
        else:
            RAPIDID=hd.group(0)
        
        joblist.append( {'RAPIDID':RAPIDID,'ID':ID,'header':headerdigest } )
        #lets get the image locations        
        
        #Detected scanner: until
        #Resampling imported data,
        #eventually we should build in if RAPID succeeded or not
    return joblist


def get_receive_log_info(fname): #extract info from receive log
    fid=open(fname)
    
    fid.seek(0)
    mystr=fid.read()
    called=[]
    for line in fid:
        m=re.findall(r'.*Called.*',line)
        called.append(m)
       
    
    
    #2) Get Calling info from this file
    multi=re.search('Called as.*rcv/([^\s]*)\s([^\s]+)\s([^\s]+)\s([0-9]*)$',mystr,re.MULTILINE)
    receivedatetime=multi.group(1)
    callerAE=multi.group(2)
    calledAE=multi.group(3)
    port=multi.group(4)
    
    #3) Also get series names
    try:
        series=re.findall('DICOM data[^-]*',mystr,re.DOTALL)[0]
        #deidentify it...
        series=re.sub('(?<=Patient: ).*',"DEIDENTIFIED",series,re.MULTILINE)
    except:
        series='None - Error'
    #series=[]
    #for line in fid:
    #    m=re.findall(r'^[\s]+.*Series.*',line,,re.DOTALL)
    #    for z in range(len(m)):
    #        series.append(m[z].lstrip())
        
      
    #now get all mismatch jobs spawned        
    fid.seek(0)
    mismatchlogs=[]
    for line in fid:
        try:
            mismatchlogs.append( re.search('^.* (Rapid3_MismatchModule.*MismatchModule.log).*$', line).group(1))
        except AttributeError:
        # AAA, ZZZ not found in the original string
            pass
        
        
    fid.seek(0)
    catchalllogs=[]
    for line in fid:
        try:
            catchalllogs.append( re.search('^.* (Rapid3_CatchAllModule.*CatchAllModule.log).*$', line).group(1))
        except AttributeError:
        # AAA, ZZZ not found in the original string
            pass    
        
        
        
    fid.close()        
    
    return {'series':series,'receivedatetime':receivedatetime, 'callerAE':callerAE,'calledAE':calledAE,'port':port,'mismatchlogs':mismatchlogs,'catchalllogs':catchalllogs}
    

parentlogfolder=sys.argv[1]
digestfolder=sys.argv[2]
noncom=['Allina', 'BIDMC', 'BWH','CCSR', 'Cincinnati', 'ClevelandClinic' ,'Columbia', 'Cornell', 'Fresno' ,'harborview', 'Hennepin' ,'Hillcrest', 'HSC_UTAH', 'Intermountain' , 'MGH' ,'Michigan', 'Moffit', 'MtSinai', 'NIH' ,'NorthWesternMemorial', 'OSUMC' ,'Palmetto', 'Seton' ,'UIowa', 'UMinnesota', 'UPenn',  'ValleyHealth' ,'Vanderbilt' ,'Wisconsin']

if len(sys.argv)==4:
     sitename=sys.argv[3]
elif (len(sys.argv)==3 ) :   #old mode
     #sys.exit(0)
     #sitename='generic'
     if os.path.exists('/opt/rapid3/local/rapid3.conf'):
         fid4=open('/opt/rapid3/local/rapid3.conf')
         lines=fid4.read()
         fid4.close()
         cline=re.findall('^.*EmailFrom.*$',lines,re.MULTILINE)[0]
         sitename=re.findall("(?<=RAPID-)[^ <]*(?=[< ])",cline)[0]
         print "T-"+sitename+"T"
         if not sitename in noncom:
             print "exiting"
             sys.exit(0)
         
         print "OK"

        

#/opt/rapid3/local/rapid3.conf
#retrieve the site name
     

#now scan what we have already
havelogs=glob.glob(parentlogfolder+"/logfile*log")


#what is there passed and complete?
#log can be MM and or CA so need to merge our two outputs here...
#MM jpbs:


#completed_log_list=glob.glob(digestfolder+"/"+ sitename+"/*/logfile_processing_2016*")

#what was completed already?
#completedfile=digestfolder+"/"+ sitename+"/completed.lst"

#if not os.path.exists("/tmp/sc"):
#    osexec("touch /tmp/sc")
#    osexec("rm -f " +digestfolder+"/completed.lst")
#    print "doing a full rerun"
    

completedfile=digestfolder+"/completed.lst"  #keep this out of the subfolder so it does not sync
completed_log_list=[]
if os.path.exists(completedfile):
    fid4=open(completedfile,'r')
    completed_log_list=fid4.readlines()
    fid4.close()
#else:
#    osexec("rm -f " + digestfolder+"/RAPID-"+ sitename+"/catchallfeed.txt") 


#CA jobs (avail from the catchall log only)
#completed_CA_logs=getCAcompletedlist(digestfolder+"/"+sitename+"/catchallfeed.txt")

#take each havelog and figure out if we have it
todolist=[]

for ilog in havelogs:
    bname=os.path.basename(ilog)
    bname_noext=re.findall("^[^\.]*",bname)[0]

    #is this one done already?
    wasdone=False
    for completed in completed_log_list:
        if bname==completed.rstrip():
            #print "ignoring " + bname
            wasdone=True
            continue
  
  #check that this log really finished provided it was not already done 
    if not wasdone:    
        fid7=open(ilog,'r')
        mylin=fid7.read()
        fid7.close()
        done=re.findall("RAPID processing finished",mylin)
        if len(done)>0:  ##ok we can add it. otherwise next iter will take it
            todolist.append(bname) 



todolist.sort()

for ilog in todolist:
    print "working on " + ilog
    fname=parentlogfolder+"/"+ilog
    
    loginfo=get_receive_log_info(fname)
  
    logfolderbase=os.path.splitext(os.path.basename(fname))[0] 
    receivedatetime=re.findall("[0-9]{8}_[0-9]{6}",logfolderbase)[0]    
    
    

    #write this out to the site log 
        
#make hierachy by Ae title

 
    if not os.path.exists(digestfolder+"/RAPID-"+sitename):
        os.mkdir(digestfolder+"/RAPID-"+sitename)

    AEfolder=digestfolder+"/RAPID-"+sitename+"/"+loginfo["callerAE"]

    if not os.path.exists(AEfolder):
        os.mkdir(AEfolder)

    receive_event_folder=AEfolder+"/"+logfolderbase
    if not os.path.exists(receive_event_folder):
        os.mkdir(receive_event_folder)
    #lets make a summary file of the receive event      
    fid=open(receive_event_folder+"/summary.txt",'w') 
    fid.writelines(["CalledAE and port: "+loginfo["calledAE"]+ " "+loginfo["port"]])   
    fid.writelines(["\n","Series List: ",loginfo["series"]]) 
    os.fsync(fid)
    fid.close()   



    #get log digest for all MM jobs        
    logdigestsMM=getMMlogdigests(parentlogfolder,loginfo["mismatchlogs"])        
        
    #get log digest for all CatchAll jobs        
    logdigestsCA=getCAlogdigests(parentlogfolder,loginfo["catchalllogs"])     
    #fid10=open(digestfolder+"/RAPID-"+sitename+"/catchallfeed.txt","a")
    fid10=open(digestfolder+"/catchallfeed_"+sitename+".txt","a")
    for z in logdigestsCA: #i believe there is always just one catchall job from this
        fid10.write("Received at " +receivedatetime +" from " + loginfo["callerAE"] +": \n")
        fid10.write(z["header"] )
        fid10.write("\n" )
    fid10.close() 
    
    osexec("cp " + digestfolder+"/catchallfeed_"+sitename+".txt " + digestfolder+"/RAPID-"+sitename+"/catchallfeed.txt") # because the entire RAPDI folder is purged, we need to append outside and then copy it in
        
    
    completed_log_list.append(ilog)

    #lets store the receive time...
    
#finally make img folders for each MM jpb spawned

#fid.writelines([logdigests[0]["header"],"\n",logdigests[0]["DICOM"]])
    indx=1
    for mmjob in logdigestsMM:
        #name=mmjob["RAPIDID"] + "_" +mmjob["ID"]
        name="MismatchJob_received_"+receivedatetime+"_INDX"+(str(indx)).zfill(2)
        cmmjob=AEfolder+"/"+logfolderbase+"/"+name
        if not os.path.exists(cmmjob):
            os.mkdir(cmmjob)
            
            
        if mmjob["PWIDICOM"]:       
            fid2=open(cmmjob+"/PWIdicomdump.txt","w")
            fid2.writelines(mmjob["PWIDICOM"])
            fid2.close()
        
        if mmjob["DWIDICOM"]:       
            fid2=open(cmmjob+"/DWIdicomdump.txt","w")
            fid2.writelines(mmjob["DWIDICOM"])
            fid2.close()        
        
        fid2=open(cmmjob+"/structure.txt","w")
        fid2.writelines(mmjob["header"])
        fid2.close()
        
        #finally copy in the maps    
        for imap in mmjob["maps"]:
            newbasename=re.sub("^.*(?=_[0-9]{8}_[0-9]{6}_.*$)", mmjob["RAPIDID"],os.path.basename(imap))
            newbasename=re.sub("_[0-9]{8}_[0-9]{6}", "",newbasename)
            #TODO - change time to receive time 
            if do_copy_maps:            
                shutil.copy(imap,cmmjob+"/"+newbasename )
        

fid4=open(completedfile,'w')
for item in completed_log_list:
  fid4.write("%s\n" % item.rstrip())

fid4.close()

   
#some general diagnostics/config from this system
dtime=str(datetime.datetime.now())

croninfo=getcroninfo()
targetfolder=digestfolder+"/RAPID-"+sitename+"/config/" + croninfo['RAPID3_PATH'] + "/local/"  #need files below local so local is top 
targetfolder_2=digestfolder+"/RAPID-"+sitename+"/config/" + croninfo['RAPID3_PATH'] + "/"
if not os.path.exists(targetfolder):
    osexec("mkdir -p " +targetfolder +"/"+sitename +"/")
    
#copy down main config files for BU and return editing.
osexec("rsync -ut " + croninfo['RAPID3_PATH'] + '/local/'  + sitename + '/config_instance.pl ' + targetfolder + sitename)
osexec("rsync -ut " + croninfo['RAPID3_PATH'] + '/Rapid3_DB.pm ' + targetfolder_2)
osexec("rsync -ut " + croninfo['RAPID3_PATH'] + '/local/'  + sitename + '/config_Rapid3_CatchAllModule.pl ' + targetfolder + sitename)
osexec("rsync -ut " + croninfo['RAPID3_PATH'] + '/local/'  + sitename + '/config_Rapid3_MismatchModule.pl ' + targetfolder + sitename)
osexec("rsync -ut " + croninfo['RAPID3_PATH'] + '/local/storescp.cfg ' + targetfolder)
osexec("rsync -ut " + croninfo['RAPID3_PATH'] + '/local/sshlatch.sh ' + targetfolder)
osexec("rsync -ut " + croninfo['RAPID3_PATH'] + '/local/rapid3.conf '  +  targetfolder)
#
#osexec("crontab -l " +  digestfolder+"/"+sitename)
if not os.path.exists(digestfolder+"/RAPID-"+sitename+"/crontab.txt"):   #if there is no crontab file then output one there since this must be the initial run
    osexec("crontab -l > " +  digestfolder+"/RAPID-"+sitename+"/crontab.txt")
#else: #if it was there then update if less than 15 minutes old (otherwise we assume)
#        



    #print p[0]
#finally, touch the OP folder   
fid10=open(digestfolder+"/RAPID-"+sitename+"/lastsync.txt","w")
hdspace=osexec1("df -h " + croninfo["RAPIDDATA"])[1][0]

fid10.write("SITEID:" +croninfo["SITEID"] + "\n" + "HD: " +hdspace+"\n"+"DateTime:"+dtime +"\n")


fid10.close()
      
 

#of this site is on the connect list, then
   #check if process is running
     #no - start it, but 

   # now test the connection via the miniperf reverse_tester
   #       if reverse tester failed, then kill process if present and re-attempt
   #       if success then all good

#if not on list, then kill any existing R-ssh connection to miniperf
 
connectsite="NIH"
#make crontab changes
if (sitename==connectsite):
    #test the connection
    #cmd="ssh perf@miniperf.stanford.edu ./testrev.py"
    #op=osexec1(cmd)
    #if not op[1][0]=="ok":
    #log into miniperf to see if we already have an active connection
    cmd="ssh -o ConnectTimeOut=10 perf@miniperf.stanford.edu \"cat conn.txt\""
    op=osexec1(cmd) 
    t=osexec1("pgrep -f -x \"ssh -o ConnectTimeOut=10 -p 22 -l perf -q -f -N -R 28112:localhost:22 miniperf.stanford.edu\"")  #test local presence
    t1=osexec1("ssh perf@miniperf.stanford.edu \" netstat -an | egrep \"tcp.*:28112.*LISTEN\" \" ") #test remote presence
    print "sitename " + op[1][0]
    print t1[0] 
    print t[0]
    print op[0]
    if ( (op[0]==0) and (op[1][0].rstrip()==connectsite) and (t[0]==0) and (t1[0]==0) ):   # file was there and we are it and connection is  up (short circuit construct)\
        #check if connection is up
        print "already connected"
        pass
    else:  #in all other cases connect
        print "connecting"
        osexec("pkill -f  -x  'ssh -o ConnectTimeOut=10 -p 22 -l perf .*miniperf.*$'") 
        sleep(1)     
        osexec("ssh -o ConnectTimeOut=10 -p 22 -l perf -q -f -N -R 28112:localhost:22 miniperf.stanford.edu")     
        cmd="ssh -o ConnectTimeOut=10  perf@miniperf.stanford.edu \"echo " +connectsite +"> conn.txt\""
        osexec(cmd)
        print("wrote conn file")
   #osexec("pkill -f  -x  'ssh -p 22 -l perf .*miniperf.*$'")    
    


#sync to base
if SYNC:
    ntrys=3
    #don't run if the previous one is still going!
    cmd="/usr/bin/flock -n /home/perf/mylock" + sitename  +  " -c '/usr/bin/rsync --timeout=15 -rut --remove-source-files /home/perf/DIGEST/RAPID-" + sitename + " perf@miniperf.stanford.edu:/home/perf/DIGEST/'"    
    for itry in range(ntrys): 
        op=osexec1(cmd)
        if (op[0]==0):
            break;
        sleep(4)          
    
 #   print cmd
 #   print op[0]
 #   print op[1]
#if not (sitename=="Intermountain" or  sitename=="Hillcrest" or sitename=="HSC_UTAH" or sitename=="Wisconsin"  or sitename=="OSUMC"):
#    sys.exit(0)


#exit now if commercial
if  (sitename=="USC" or  sitename=="Lifespan" or sitename=="UTMemorialHermann" or sitename=="OHSU" or sitename=="Providence" ):
    print "exiting commercial"
    sys.exit(0)

pushsites=['MtSinai','Vanderbilt','ValleyHealth','Scripps','OSUMC','Michigan','Fresno','Cincinnati','UMinnesota','Providence','MGH','Cornell','ClevelandClinic','BWH','Columbia','UIowa','harborview','Hillcrest','Hennepin','UPenn','NorthWesternMemorial','Allina','NIH','BIDMC','Moffit']
#push config out for these sites
if  (sitename in pushsites): #sync back the edited files
    osexec("rsync -rut perf@miniperf.stanford.edu:~/DIGEST/RAPID-" + sitename + "/config/ /")



#if there is a crontab_new.txt file, then read that in..
osexec("rsync -avv --remove-source-files  --no-group perf@miniperf.stanford.edu:~/DIGEST/RAPID-" + sitename + "/crontab_new.txt " +  digestfolder+"/RAPID-"+sitename+"/")

if os.path.exists(digestfolder+"/RAPID-"+sitename+"/crontab_new.txt"):
    osexec("crontab -l > /tmp/crontab_" + dtime.replace(' ','T') )
    p=osexec("cat " + digestfolder+"/RAPID-"+sitename+"/crontab_new.txt  | crontab -")
    osexec("rm -f " + digestfolder+"/RAPID-"+sitename+"/crontab_new.txt")     
    print "installed new crontab"
else:
    print "no new crontab"


#finally sync the time with miniperf
#op=osexec("rsync -avv --remove-source-files  --no-group perf@miniperf.stanford.edu:~/DIGEST/RAPID-" + sitename + "/crontab_new.txt " +  digestfolder+"/RAPID-"+sitename+"/")



#print "rsync -avv --no-group perf@miniperf.stanford.edu:~/DIGEST/RAPID-" + croninfo['SITE'] + "/crontab.txt " +  digestfolder+"/"+sitename+"/crontab.txt | grep '^cronta'"
#print op[0]
#print op[1]
    
     
#if not op[0].rstrip() == 'crontab.txt is uptodate': #if not up to date what we have then add the updated crontab here afte rmaking a backup
#    osexec("crontab -l > /tmp/crontab_" + dtime.replace(' ','T') )
#    if os.path.exists(digestfolder+"/RAPID-"+sitename+"/crontab.txt"):
#        p=osexec("cat " + digestfolder+"/RAPID-"+sitename+"/crontab.txt  | crontab -")
#        print "injected new crontab: "    +"cat " + digestfolder+"/"+sitename+"/crontab.txt  | crontab -"     
      


      
 
     
      
#now write out well formated txt:
#print "ReceiveTime: "+receivedatetime
#print "CallerAE: "+callerAE 
#print "CalledAE: "+calledAE
#print "Port: " + port
#print "SeriesDigest: "+series
#print "LogDigest: "+logdigests[0]
       
