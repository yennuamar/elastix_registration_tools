#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 25 10:00:08 2017

@author: sorenc
 
 
"""

#look up Series that arrived between 2 timepoints. Received files are oftn only available in the DB minutes after they transmission started. So each time we look we add in a 10 minute clearance window. This should be sufficient,


import os


import datetime
import subprocess
import getpass
import re
from time import sleep

 
def osexec(cmd):
    pid = subprocess.Popen(cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
    op = pid.communicate()
    #print pid.poll()
    return (op,pid.poll())
 

    

 
 
def transferid_date_time(lasttime,datetime_now,site):
    # cmd="ssh perf@172.25.169.28 \"psql -d rapid -U perfuser -c \"select rapid_transfer_id,transfer_date_time from mni_transfers where transfer_date_time >= \'2017-03-03 00:00:00.000000\' and transfer_date_time <= \'2017-03-04 00:00:00.000000\' \"\""
    psqlcmd="psql  -d rapid -U perfuser -c \"select * from (select  SITE_series.rapid_patient_id,rapid_series_id, series_description, called_aetitle, calling_aetitle, rapid_transfer_id,transfer_date_time, series_date_time, count(*) from SITE_transfers inner join SITE_instance using (rapid_transfer_id) inner join SITE_series using (rapid_series_id) group by SITE_series.rapid_patient_id, rapid_series_id, series_description, called_aetitle, calling_aetitle,rapid_transfer_id, series_date_time, transfer_date_time order by transfer_date_time ) as tmp where transfer_date_time >= \'" + lasttime + "\'  and transfer_date_time <= \'" + datetime_now+ "\'  \"  "
    psqlcmd=psqlcmd.replace("SITE",site)
    print psqlcmd
    cmd1=psqlcmd
    #cmd1= "ssh perf@172.25.169.28 \"" +  psqlcmd +"\""
    op1=osexec(cmd1)
             
    return op1
 
def sync2base(sitename):  
    ntrys=3
    #don't run if the previous one is still going!
    cmd="/usr/bin/flock -n /home/perf/mylock46" + sitename  +  " -c '/usr/bin/rsync --timeout=15 -rut  /home/perf/DIGEST/" + sitename + " perf@miniperf.stanford.edu:/home/perf/DIGEST/'"    
    for itry in range(ntrys): 
        op=osexec(cmd)
        if (op[1]==0):
            break;
        sleep(4)          
    
    
def append_rcv_dicom_to_log():
    user=getpass.getuser()    
    #retrieve the last run time
    if os.path.isfile("/home/"+ user +"/.lasttime"):
        lasttime= open("/home/"+ user +"/.lasttime", "r").read()       
    else:    
        lasttime="2016-01-01 00:00:00"   #minus inf
    
    rightnow = datetime.datetime.today()
    rightnow= rightnow.replace(second=0, microsecond=00000) - datetime.timedelta(minutes=10)
     
    
    
    sitenames=['mni']    
    if os.path.exists("/rapid_data/rcv"): 
        tmp=osexec("ls /rapid_data/rcv")    
        sitenames=tmp[0][0].strip().split('\n')
        
    for site in  sitenames:
        op1=transferid_date_time(lasttime,str(rightnow),site)
        sitelog="/home/perf/DIGEST/" +site + "/R46receive.log"
        
        if not os.path.exists("/home/perf/DIGEST/" +site):
            try:
                osexec("mkdir -p " +"/home/perf/DIGEST/" +site)
            except:
                sitelog='/home/sorenc/DIGEST/mni/R46receive.log' #test mode with no perf user
        with open(sitelog, "a+") as out_file:
            out_file.write(lasttime + ": to " +str(rightnow)+ ":\n")
            out_file.write(op1[0][0])
            out_file.flush()
            
            
        sync2base(site)
            
            
    with open("/home/"+ user +"/.lasttime", "w") as f:
        f.write(str(rightnow))

    

append_rcv_dicom_to_log()

 
###select * from (select  mni_series.rapid_patient_id, rapid_series_id, series_description, called_aetitle, calling_aetitle, rapid_transfer_id,transfer_date_time, series_date_time, count(*) from mni_transfers inner join mni_instance using (rapid_transfer_id) inner join mni_series using (rapid_series_id) group by mni_series.rapid_patient_id, rapid_series_id, series_description, called_aetitle, calling_aetitle,rapid_transfer_id, series_date_time, transfer_date_time order by transfer_date_time ) as tmp where transfer_date_time >= '2017-04-25 10:16:00'::timestamp - interval '120 days' and transfer_date_time <= '2017-04-25 10:16:00';