import re
import numpy as np

np.set_printoptions(linewidth=10000)
fname="log.log"

fid=open(fname)


mystr=fid.read()
called=[]

times=re.findall('.*lices\):\n(.*)\nResampling imported data.*$',mystr,re.DOTALL)[0].split('\n')
#lets turn this into a np matrix to play with it here

tmp=[float(x) for x in times[0].split()]

timemat=np.zeros((len(times),len(tmp)),dtype=float)


for k in range(len(times)):
    tmp=[float(x) for x in times[0].split()]
    timemat[k,:]=tmp
    

timemat=timemat.astype(int)*1000     #get ms precision


#lets work out if 
#1) Slice uniform equidistant
#2) bi-phasic, equidistant
#3) slice multiphasic, non equidistant
#4) slice uniform, non equidistant  

tdiff=np.diff(timemat,axis=1)

delta_diffs=np.diff(tdiff,axis=1)

isequidistant=not(np.any(delta_diffs))

slicediff=np.diff(timemat,axis=0)
isslice_varying=np.any(slicediff)   #any differences apart from 0?

scheme='';
#ad 1)
if (not(isslice_varying) and isequidistant):
    scheme='uniform_equidistant'

if (not(isslice_varying) and not(isequidistant)):
    scheme='uniform_nonequidistant'

#now to tease out toggle from spiral.. Toggle is usually equidistant, but I believe there can be milli second differences
#both will be slice varying, but toggle will have identical sampling times in all rows, continous will not..
#turn to a void view (not sure why this works...)

#below trick does not work...
#fac=timemat.dtype.itemsize * timemat.shape[1]
#voidview = np.ascontiguousarray(timemat).view(np.dtype((np.void, fac)))
#idx = np.unique(voidview, return_index=True)    #seems idx comes out empty somehow
#uniquerows= timemat[idx]
diffvec=np.zeros( (timemat.shape[0],),dtype=bool)

for k in range(1,timemat.shape[0]):
    diffvec[k]=np.any(timemat[k,:]-timemat[k-1,:])
    
    
#this counts how many times the acquisition scheme changes
#if just once, it is toggle.   If more than once, it is continous spiral

if sum(diffvec)==1:


if sum(diffvec)>1:

    