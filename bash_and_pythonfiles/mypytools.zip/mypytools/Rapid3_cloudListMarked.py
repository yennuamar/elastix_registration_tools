#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys

fh=open("translation_table.txt")
lines=fh.readlines()
fh.close()

siteID=sys.argv[1]
trial=sys.argv[2]

if not trial=='DEFUSE3':
    sys.exit(0)
    
lines=lines[1:];

for cline in lines:
    if cline.rstrip():
        mysplit=cline.rstrip().split(",")
        for iID in mysplit[1:]:
            if iID[0:3]==siteID:    
                print iID + ",DEFUSE3"
    