# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 15:50:20 2016

@author: sorenc
"""

import sqlite3
import datetime
import re
import os
import numpy as np
import subprocess
import gdcm
taglist=['PatientName','Modality', 'InstanceNumber','PatientID' ,'PatientAge','PatientSex','StudyDate' ,'StudyTime', 'SeriesDescription', 'InstanceNumber', 'SeriesInstanceUID' , 'SeriesTime', 'SeriesDate' ]

def queryfile(pos):
#get standard tag values from file if DCM
  
    r = gdcm.Reader()
    r.SetFileName( pos )
    success = r.ReadSelectedTags(TAGVEC)
    op={};
    if not success:
        op["ISDICOM"]=0
        return op
    

    sf=gdcm.StringFilter()
    sf.SetFile(r.GetFile());
    tagdict={}
    for itag in range(len(TAGVEC)):
        #print sf.ToString(ctag)
        content=sf.ToString(TAGVEC[itag])
        content=re.sub('[^a-zA-Z0-9\.\-_]+','',content)
           
        if len(content)==0:
            content="NA"
        
        if taglist_sorted[itag]=="StudyTime":
            content=re.sub('\.[0-9]+','',content)
     
        tagdict[taglist_sorted[itag]]=content
    #regularize
    
  
    
    op["ISDICOM"]=1
    op["dict"]=tagdict
    return op


def osexec1(cmd):
    pid = subprocess.Popen(cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)  #the +p prepends the hierachy and makes sure the match below only takes lavel one occurences...
    op = pid.communicate()
    return (pid.poll(),op)

def filedict2png(seriesdict,location):
    ID=seriesdict["ID"]
    datelabel=seriesdict["datelabel"]
    #datetime=seriesdict["datetime"]    
    #seriesdesc=seriesdict["seriesdesc"]

    targetfolder=location + "/" + ID + "/" +datelabel +"/"
    osexec1("mkdir  -p "+ targetfolder)
    
    for ifile in seriesdict["urllist"]:
          targetname=os.path.basename(ifile) 
          targetname=re.sub('\.dcm','.png',targetname)
          osexec1("mkdir  -p "+ targetfolder)
          osexec1("dcmj2pnm +Wm +on " +ifile + " "+ targetfolder+targetname)
          
          
def retrieve_dicoms(ID,datelabel,seriesdesc,datetime,ZID,files):
    #create a subfolder for ID/datetime/seriesnumber and dump the dicoms there by rsyncing with imac
    
           
    #prep an export data structure that makes it easy to convert this to png
    filedict={}    
    filedict["ID"]=ID;    
    filedict["datelabel"]=datelabel    
    filedict["datetime"]=datetime
    filedict["seriesdesc"]=seriesdesc
    filedict["urllist"]=[]
    #work out the output folder name
    
    if not os.path.exists('/home/sorenc/RAPIDOSIRIX/'):
        osexec1("mkdir /home/sorenc/RAPIDOSIRIX/")        
    for k in files:
        loc=str( int(np.ceil(float(k[0]+1)/10000.0)*10000)) + "/" +str(k[0]) + ".dcm"
        print loc
 
        
        cmd="scp sorenc@imac:~/Documents/OsiriX*Data/DATABASE.noindex/" + loc + " tmp.dcm"
        op=osexec1(cmd)
        if not (op[0]==0):
            print "failed to retrieve " + loc
            print op[1]
            return
        #query for instancenumber  
        op=queryfile("tmp.dcm")
        assert(op["dict"]["PatientID"]==ID)
        instancenumber=op["dict"]["InstanceNumber"]
        
        #mrdict={"61_1":"Columns","61_10":"AIFVOFPlot","61_100":"AIFVOFlocation","61_2":"Core","61_3":"Summary","60_4":"Tmax","61_4":"Tmax","60_3":"Summary","60_2":"Core"}
        ctdict={"60_1":"Columns","61_1":"Columns","61_10":"AIFVOFPlot","60_10":"AIFVOFPlot","61_100":"AIFVOFlocation","61_2":"Core","61_3":"Summary","60_4":"Tmax","61_4":"Tmax","60_3":"Summary","60_2":"Core"} #turns out identical...
        #lets give this image a name
        series_instancenumber=ZID[-2]+ZID[-1]+"_"+instancenumber
        if op["dict"]["Modality"]=="CT":
            imagetype="CT_"+ctdict[series_instancenumber]         
        else:
            imagetype="MR_"+ ctdict[series_instancenumber]         
        
        seriesdatetime=op["dict"]["SeriesDate"] + "T" +op["dict"]["SeriesTime"] 
        opurl="/home/sorenc/RAPIDOSIRIX/" +ID+"_"+datelabel+"_"+datetime+"_"+ZID+"_" +imagetype+".dcm"      #"_"+re.sub(" ","_",seriesdesc)+
        #print opurl
        filedict["urllist"].append(opurl)
        osexec1("mv tmp.dcm " +opurl)
        
    return filedict
   
    
    
def regexp(expr, item):
    reg = re.compile(expr)
    return reg.search(item) is not None




#CREATE THE TAGVEC needed for querying individual files
singleton = gdcm.Global.GetInstance()
dicts = singleton.GetDicts()
d = dicts.GetPublicDict()

TAGVEC=gdcm.TagSetType()

for k in taglist:
    optag=gdcm.Tag()
    tagname=d.GetDictEntryByKeyword( k,optag )
    #print k
    if optag.GetGroup()==65535:
        sys.stderr.write("Fatal error - could not parse dictionary")
        exit(1)
    #ctag=gdcm.Tag(optag)
    TAGVEC.insert(optag)
taglist_sorted=[]
#now get a keywordlist in the same sorted order as TAGVEC
for k in TAGVEC:
    taglist_sorted.append(d.GetKeywordFromTag(k))
    







conn = sqlite3.connect('Database.sql')
c = conn.cursor()
conn.create_function("REGEXP", 2, regexp)
#op=c.execute('select distinct ZNAME from zseries where ZNAME REGEXP ''RAPID''')
t=c.execute('SELECT Z_PK,ZID,ZSTUDY,ZCOMMENT,ZCOMMENT2,ZDATE,ZNAME,ZMODALITY FROM ZSERIES WHERE ZNAME REGEXP ?',['.*RAPID Summary.*'])    #
names = list(map(lambda x: x[0], t.description))

op=c.fetchall()

seriesdictarr=[]
#now make and array of series dicts
for k in op:
    mydict={}
    for iname in range(len(names)):
        mydict[names[iname]]=k[iname]
        
    seriesdictarr.append(mydict)     

unixTS = 978307200 #  Jan 1 2000

doIDs=['211','212','224','233','242','246','250','253']
#create a list of ID, TP, DATETIME and then later uniqify that
capturelist=set()

for cseries in seriesdictarr:  #iterate all series called RAPID summary
    #print row
    seriesnumber=str(cseries["ZID"])                 #get the series #
    if  re.match('.*6[0-1]$',seriesnumber):               # *60 or 61
        #print row   #ZPATIENTID=\'102\' AND
        b=c.execute('SELECT ZPATIENTID,ZCOMMENT,ZMODALITY FROM ZSTUDY WHERE  Z_PK='+str(cseries["ZSTUDY"]) )  #get the pertaining patient and timecomment from study table
       
        IDandComment=b.fetchall()   
        
        #if len(IDandComment)==0:  #use this when limiting IDs
        #    continue                 
        modality=IDandComment[0][2]                                               
        ID=IDandComment[0][0]
        print ID
        if len(ID)>3:
            continue
        
        if (not int(ID)==215 ):
            continue
        datelabel="UNK"
        if (IDandComment[0][1]):                                             #use UNK if data label is not dfines
            datelabel=IDandComment[0][1]
        a=c.execute('SELECT ZPATHNUMBER FROM ZIMAGE WHERE ZSERIES='+str(cseries["Z_PK"]) )  #cget paths for all images in this series
        myfiles=c.fetchall()           #these are the files belonging to that series
        dt=str(datetime.datetime.fromtimestamp(unixTS + cseries["ZDATE"]).strftime("%Y%m%dT%H%M%S") )          #convert to datetime
        print "found study for " +  ID + " Modality: " + cseries["ZMODALITY"] + " from " + dt + " with " + str(len(myfiles)) + " dicoms and date label " +datelabel   
        
        filedict=retrieve_dicoms(ID,datelabel,cseries["ZNAME"],dt,str(cseries["ZID"]),myfiles)       
        
        filedict2png(filedict,'/carpathia/running_studies/D3/CORELAB/png_march/')        #turn the DICOMs into pngs
        
        
        capturelist.add(ID + "_"+datelabel+ "_"+dt+'_'+modality) #this is any RAPID image so includes VOF etc
                
        
        #for irow in myfiles:            
        #    print "image " + str(irow)
            
        #now convert series to png
        #series2png(seriesdescriptor,filelist,outputfolder)
    


    
    
    
conn.close()



#lets go throught the capturelist and for each ID let us identify all scans labelled BL. Select the last one for both MR and CT
#iterate and get just BL times per ID

BLdict={}
FUdict={}
for series in capturelist:
     tmp=series.split('_')   
     ID=tmp[0]
     TP=tmp[1]
     datetime=tmp[2]
     if TP=='BL':
         if not BLdict.has_key(ID):
              BLdict[ID]=[datetime]
         else:
              BLdict[ID].append(datetime)     
              
     if TP=='FU':
         if not FUdict.has_key(ID):
              FUdict[ID]=[datetime]
         else:
              FUdict[ID].append(datetime)              
              
 
 
#now output the datetime for each ID showing the last scan. So if PWI this would be PWI time (via VOF or column OP), if DWI only it will be DWI summary time
IDs=sorted(BLdict.keys())
for cID in IDs:
    BLdate=sorted(BLdict[cID])[-1]
    FUdate='NA'
    if FUdict.has_key(cID):
        FUdate=sorted(FUdict[cID])[-1]
    print cID+","+BLdate+','+FUdate
 
#todo: eg 493404698 to date
sys.exit(0)
#get the sheet from coord center 
import csv
#csvfile='IMAGINGDATA_CTP_MRP_09212016.csv'
csvfile='IMAGINGDATA_CTP_MRP_BET_21SEP2016_AND_30NOV2016.csv'

#csvfile="/home/sorenc/TESTS/assessment451.csv"
csvobj=csv.DictReader(open(csvfile))
myfieldnames=csvobj.fieldnames
dat=list(csvobj)
import datetime
#write out NIH sheet with our time style and add in difference too
for row in dat:
    nID=row["zSubjectID"]
    nsite=row["zSiteNm"]
    tmp=row["SCAN_DT"].split('/')
    nhour=row["SCANHR"]
    nminute=row["SCANMIN"]
  
    ndatetime=datetime.datetime(int(tmp[2]),int(tmp[0]),int(tmp[1]),int(nhour),int(nminute)) 
  
    nlabel=row["LABEL"]
    
    hasdata=0
    #find match from Osirix
    if nlabel=='BL':
        if BLdict.has_key(nID):
            osdatetime=datetime.datetime.strptime(sorted(BLdict[nID])[-1], "%Y%m%dT%H%M%S" )
            delta=osdatetime-ndatetime   
            deltastr=str( int(round( delta.total_seconds()/60)))
            hasdata=1
            if nID=='165':
                print "hello"
            #print deltastr
   
            
    if nlabel=='FU':  #may not always be present
        if FUdict.has_key(nID):
            osdatetime=datetime.datetime.strptime(sorted(FUdict[nID])[-1], "%Y%m%dT%H%M%S" )
            delta=osdatetime-ndatetime   
            deltastr=str( int(round( delta.total_seconds()/60)))

            hasdata=1
     
    if hasdata:
        print nID +","+nsite +","+ndatetime.strftime('%Y%m%dT%H%M')+","+ osdatetime.strftime('%Y%m%dT%H%M')+","+ deltastr
    else:
        print nID +","+nsite +","+","+ndatetime.strftime('%Y%m%dT%H%M') +",NA","NA"
            
    #osdatetime now avail, print result
            
   