# -*- coding: utf-8 -*-
"""
Created on Fri Apr 15 15:41:09 2016

@author: sorenc
"""

import numpy as np
import matplotlib.pyplot as plt
import numpy.matlib
import matplotlib.image as mpimg
import pickle

def analyze(dirname,analysis,logic,modal,volumeparam,testlabel):


    #textual display of number of failures etc         
    modallogic=np.ones(len(logic),dtype=np.bool)
    if modal=="MR":
        
        modallogic= analysis["modalarray"][0,:]==0
    elif modal=="CT":
       modallogic=analysis["modalarray"][0,:]==1
    else:
       print "no modal selection, including all"
       
       
    logic=np.logical_and(logic,modallogic)    
    
    indcs=np.argwhere(logic)
    print "including " +str(len(indcs)) + " cases"
    volarray=analysis[volumeparam][:,logic]
    
    
    imagesV1=[analysis["imagesV1"][k[0]] for k in indcs]
    imagesV2=[analysis["imagesV2"][k[0]] for k in indcs]
    corrs=analysis["corrs"]
    IDs=[analysis["IDs"][k[0]]  for k in indcs]
    
    fig = plt.figure(1)
    ax = fig.add_subplot(111)
      
    plt.plot([0,600],[0,600],'b') 
    plt.plot([0,600],[0,540],'r')  
    plt.plot([0,600],[0,660],'r')  
    plt.scatter(volarray[0,:],volarray[1,:])    
    plt.xlabel('4.5.1')
    plt.ylabel('4.6')
    plt.title(volumeparam)
    
    
    
    fig2=plt.figure(2)
    IDref = fig2.suptitle('ID')
    
    fig3=plt.figure(3)
    IDref3 = fig3.suptitle('ID')
    
    
    
    def onclick(event):
        if event.inaxes:
            #print "%f,%f" % (event.xdata, event.ydata)
            #construct a vector to compare to the tmaxarray location
            mymat=numpy.matlib.repmat( np.mat([[event.xdata],[event.ydata]]),1,volarray.shape[1])
            powermat=np.power(mymat-volarray,2)        
            diffvec=np.power(np.sum(powermat,axis=0),0.5)
         
            minpos=np.nanargmin(diffvec)
            print diffvec[0,minpos]
            if diffvec[0,minpos]<5:
                cID=IDs[minpos]
                print IDs[minpos]
                #xy=tmaxarray[:,minpos]
                #plt.figure(1)         
                #ax.annotate(IDs[minpos] , xy=xy, textcoords='data')
                #plt.text(xy[0],xy[1],IDs[minpos])                     
                #plt.draw()
                #print "minpos "+ str(minpos)
                plt.figure(2)
                try:
                    myimg=mpimg.imread(dirname+imagesV1[minpos][0])
                    print dirname+imagesV1[minpos][0]
                except:
                    print "error " + str(minpos) 
                    print len(imagesV1)
                    print len(imagesV1[minpos])
                    print dirname+imagesV1[minpos][0]
                    return
                myimg1=mpimg.imread(dirname+imagesV2[minpos][0])

                plt.subplot(2,1,1)
                plt.cla()
                imgplot = plt.imshow(myimg,interpolation='nearest')     
                plt.axis('off')
                plt.title("r451")
                
                plt.subplot(2,1,2)
                plt.cla()
                imgplot1 = plt.imshow(myimg1,interpolation='nearest')
                plt.title("r46")   
                #plt.suptitle(IDs[minpos])
                plt.axis('off')            
                IDref.set_text(cID+ " %2.1f mL ,%2.1f mL" % (volarray[0,minpos],volarray[1,minpos]))
                plt.draw()
                
                plt.figure(3)
                plt.subplot(2,2,1)
                plt.cla()          
                plt.plot( corrs[ cID ]["v1corr"] ,'b')
                plt.title("r451corr sc")   
                plt.ylim( 0.90, 1 ) 
                
                plt.subplot(2,2,2)
                plt.cla()          
                plt.plot( corrs[ cID ]["v2corr"] ,'b')
                plt.title("r46corr sc")   
                plt.ylim( 0.90, 1 ) 
                
                
                plt.subplot(2,2,3)
                plt.cla()          
                plt.plot( corrs[ cID ]["v2json_pre_corr"] ,'b')
                plt.title("r46json_pre_corr")   
                plt.ylim( 0.90, 1 ) 
                
                
                plt.subplot(2,2,4)
                plt.cla()          
                plt.plot( corrs[ cID ]["v2json_post_corr"] ,'b')
                plt.title("r46json_post_corr")   
                plt.ylim( 0.90, 1 )             
                IDref3.set_text(cID)
                
                plt.draw()
            #diffmat=np.power( np.sum(),0.5)
            #print diffmat.shape        
            
            
        
    fig.canvas.mpl_connect('button_press_event', onclick)



    plt.show()   




dirname="/home/sorenc/TESTS/"
testname="v1_vs_v2_20161207T203545"

fp=open(dirname + testname +".p") 
analysis = pickle.load(fp)
fp.close()

failure_mat=analysis["failure_mat"]
#get the stats for the PPT
analysis["artefact_tmax"]==-1
v451failures=np.sum(failure_mat[0,:])
IDs=analysis["IDs"]
modal=analysis["modalarray"]

MRcount=np.sum(modal[0,:]==0)


len(IDs)  #521
failureIDs451=[IDs[k[0]] for k in np.argwhere(failure_mat[0,:])]
#15 cases failed in 4.5.1, mixture of no contrast, bolus too early, and a few cases triggering a bug

#failures in 4.6
failureIDs46=[IDs[k[0]] for k in np.argwhere(failure_mat[1,:])]
#have some additional cases - need to tease out the details here

#we exclude cases that fail in bot versions for now
v1orv2failure=np.sum(analysis['failure_mat'],0)>0
np.sum(v1orv2failure)  #19

np.sum( np.logical_and(analysis["artefact_tmax"]==1,  modal[0,:]==1))  #36 MR 35 CT
no_failures_good451only=np.logical_and(v1orv2failure==False,analysis["artefact_tmax"]==0)
analyze(dirname,analysis,no_failures_good451only,"CT","tmaxarray","non artefact only")
analyze(dirname,analysis,no_failures_good451only,"CT","corearray","non artefact only")
analyze(dirname,analysis,no_failures_good451only,"MR","tmaxarray","non artefact only")
analyze(dirname,analysis,no_failures_good451only,"MR","corearray","non artefact only")

#analyze(dirname,analysis,no_failures_good451only,"CT","tmaxarray","non artefact only")




