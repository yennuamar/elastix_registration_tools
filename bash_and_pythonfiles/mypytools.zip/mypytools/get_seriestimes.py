#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 12 22:16:58 2017

@author: amar
"""



import xlsx
import os
import xlrd
import datetime
import dicom




#MAIN

#webdcu_corevols=xlsx.xlsx('/Users/amar/Desktop/webdcuvolumes_test.xlsx')
#webdcu_corevols=xlsx.xlsx('/Users/amar/Desktop/Corevolumedata_6_13_17.xlsx')
webdcu_corevols=xlsx.xlsx('/Users/amar/Desktop/Mismatchclass/IMAGINGDATA_CTP_MRP_23JUN2017_updated.xlsx')

#perfusion_output_folder='/Users/amar/Desktop/testcases_stanfordcleanup/results_r45/'
perfusion_output_folder='/Volumes/RAPID_PROCESSING/D3_Volumes_pre_correction'


#compareBLcore=[] for i in range(4)]
#i=0
subjectid=webdcu_corevols["zSubjectID"]
BLorFU=webdcu_corevols["BL_FU"]

scandate=webdcu_corevols["SCAN_DT"]
scandatetime_webdcu=[]
scanhour=webdcu_corevols["SCANHR"]
scanminute=webdcu_corevols["SCANMIN"]
dict={}
for i in range(len(scandate)):
    year, month, day, hour, minute, second = xlrd.xldate_as_tuple(int(scandate[i]), 0 )
    scandatetime_webdcu.append(datetime.datetime(year,month,day,int(scanhour[i]),int(scanminute[i])))
    print(scandatetime_webdcu[i])


scandatetime_corelab_selected=[]
time_elapsed=[]


for i in range(len(subjectid)):
 
#    if BLorFU[i] == 'BL' or BLorFU[i] == 'FU':
    usefolders1=[]
    usefolders2=[]
    folder = perfusion_output_folder + '/' + subjectid[i] + '/' + BLorFU[i]
    if os.path.exists(folder+'/CTP1/') or os.path.exists(folder+'/PWI1/'):
        try:
            usefolders1=os.listdir(folder+'/CTP1/') 
            folderuse1=folder+'/CTP1/'
        except:
            usefolders1=os.listdir(folder+'/PWI1/') 
            folderuse1=folder+'/PWI1/'
        
    if os.path.exists(folder+'/CTP2/'):       
        usefolders2=os.listdir(folder+'/CTP2/') 
        folderuse2=folder+'/CTP2/'
  
    scandatetime_corelab=[]
    
    if not usefolders1:
        scandatetime_corelab.append(datetime.datetime(1111,1,1,1,1))
    else:
        dicom1=dicom.read_file(folderuse1+usefolders1[0])

        scandatetime_corelab.append(datetime.datetime(int(dicom1.SeriesDate[0:4]),int(dicom1.SeriesDate[4:6]),int(dicom1.SeriesDate[6:8]), int(dicom1.SeriesTime[0:2]), int(dicom1.SeriesTime[2:4])))
    
    if not usefolders2:
        scandatetime_corelab.append(datetime.datetime(1111,1,1,1,1))
    else:
        dicom2=dicom.read_file(folderuse2+usefolders2[0])

        scandatetime_corelab.append(datetime.datetime(int(dicom2.SeriesDate[0:4]),int(dicom2.SeriesDate[4:6]),int(dicom2.SeriesDate[6:8]), int(dicom2.SeriesTime[0:2]), int(dicom2.SeriesTime[2:4])))
       
        
    scandatetime_corelab=sorted(scandatetime_corelab)
    scandatetime_corelab_selected.append(scandatetime_corelab[1])
    timediff=(scandatetime_webdcu[i]-scandatetime_corelab_selected[i])
    time_elapsed.append(timediff.total_seconds()/(60*60))
    dict={'Patient1d': subjectid[i], 'BLorFU': BLorFU[i] ,'scandatetime_webdcu':str(scandatetime_webdcu[i]),'scandatetime_corelab_selected':str(scandatetime_corelab_selected[i]),'time_elapsed':time_elapsed[i]}
    with open('/Users/amar/Desktop/Mismatchclass/' + 'seriesdatetimes.txt', 'a') as f:
        print(dict.values(),file=f)
#    print(scandatetime_webdcu[i])
#    print(scandatetime_corelab_selected[i])
#    print(time_elapsed[i])
        