#ifndef SC_ITKIMPORTER
#define SC_ITKIMPORTER
#include <QStringList>


class sc_itkimporter {
public:
    sc_itkimporter();

    ~sc_itkimporter();
    bool readFiles(std::string str);
    //char* getBuffer();
    short* getBuffer();
    int* getDims();
private:
    char *buffer;
    bool isinit;
    int dims[4];
};

#endif
